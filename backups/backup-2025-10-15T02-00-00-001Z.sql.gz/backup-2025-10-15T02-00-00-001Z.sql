--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (165f042)
-- Dumped by pg_dump version 16.9

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: drizzle; Type: SCHEMA; Schema: -; Owner: neondb_owner
--

CREATE SCHEMA drizzle;


ALTER SCHEMA drizzle OWNER TO neondb_owner;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: __drizzle_migrations; Type: TABLE; Schema: drizzle; Owner: neondb_owner
--

CREATE TABLE drizzle.__drizzle_migrations (
    id integer NOT NULL,
    hash text NOT NULL,
    created_at bigint
);


ALTER TABLE drizzle.__drizzle_migrations OWNER TO neondb_owner;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE; Schema: drizzle; Owner: neondb_owner
--

CREATE SEQUENCE drizzle.__drizzle_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNER TO neondb_owner;

--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: drizzle; Owner: neondb_owner
--

ALTER SEQUENCE drizzle.__drizzle_migrations_id_seq OWNED BY drizzle.__drizzle_migrations.id;


--
-- Name: ab_test_participants; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.ab_test_participants (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    test_id character varying NOT NULL,
    participant_id text NOT NULL,
    variant text NOT NULL,
    converted boolean DEFAULT false,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ab_test_participants OWNER TO neondb_owner;

--
-- Name: ab_tests; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.ab_tests (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    resource_type text NOT NULL,
    resource_id character varying,
    variants jsonb NOT NULL,
    status text DEFAULT 'draft'::text,
    winner_variant text,
    start_date timestamp without time zone,
    end_date timestamp without time zone,
    metrics jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ab_tests OWNER TO neondb_owner;

--
-- Name: account_lockouts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.account_lockouts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    locked_at timestamp without time zone DEFAULT now(),
    locked_until timestamp without time zone NOT NULL,
    lock_reason text,
    failed_attempts integer DEFAULT 0,
    last_attempt_at timestamp without time zone,
    unlocked boolean DEFAULT false,
    unlocked_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.account_lockouts OWNER TO neondb_owner;

--
-- Name: affiliates; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.affiliates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    code text NOT NULL,
    commission_rate numeric(5,2) DEFAULT 10.00,
    total_earnings numeric(10,2) DEFAULT '0'::numeric,
    total_referrals integer DEFAULT 0,
    status text DEFAULT 'active'::text,
    payment_info jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.affiliates OWNER TO neondb_owner;

--
-- Name: ai_cost_tracking; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.ai_cost_tracking (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    provider text NOT NULL,
    model text NOT NULL,
    feature text NOT NULL,
    prompt_tokens integer NOT NULL,
    completion_tokens integer NOT NULL,
    total_tokens integer NOT NULL,
    estimated_cost numeric(10,6) NOT NULL,
    request_duration_ms integer,
    success boolean DEFAULT true,
    error_message text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ai_cost_tracking OWNER TO neondb_owner;

--
-- Name: ai_predictions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.ai_predictions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    model_id character varying NOT NULL,
    user_id character varying,
    input_data jsonb NOT NULL,
    prediction jsonb NOT NULL,
    confidence numeric(5,2),
    actual_outcome jsonb,
    was_accurate boolean,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ai_predictions OWNER TO neondb_owner;

--
-- Name: ai_provider_failover; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.ai_provider_failover (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    provider text NOT NULL,
    state text DEFAULT 'CLOSED'::text NOT NULL,
    failure_count integer DEFAULT 0 NOT NULL,
    consecutive_failures integer DEFAULT 0 NOT NULL,
    last_failure_at timestamp without time zone,
    last_success_at timestamp without time zone,
    last_health_check_at timestamp without time zone,
    is_available boolean DEFAULT true,
    latency_ms integer,
    error_message text,
    cooldown_until timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ai_provider_failover OWNER TO neondb_owner;

--
-- Name: ai_rate_limits; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.ai_rate_limits (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    window_start timestamp without time zone NOT NULL,
    request_count integer DEFAULT 1 NOT NULL,
    last_request_at timestamp without time zone DEFAULT now(),
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ai_rate_limits OWNER TO neondb_owner;

--
-- Name: ai_training_data; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.ai_training_data (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    data_type text NOT NULL,
    input jsonb NOT NULL,
    output jsonb NOT NULL,
    feedback jsonb,
    quality_score numeric(5,2),
    is_approved boolean DEFAULT false,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ai_training_data OWNER TO neondb_owner;

--
-- Name: analytics; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.analytics (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    event_type text NOT NULL,
    event_name text,
    resource_type text,
    resource_id character varying,
    value numeric(10,2),
    metadata jsonb,
    user_agent text,
    ip_address text,
    referrer text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.analytics OWNER TO neondb_owner;

--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.api_keys (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    key_hash text NOT NULL,
    key_prefix text NOT NULL,
    last_used_at timestamp without time zone,
    expires_at timestamp without time zone,
    revoked_at timestamp without time zone,
    scopes jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.api_keys OWNER TO neondb_owner;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.audit_logs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    action text NOT NULL,
    resource text,
    resource_id text,
    details jsonb,
    ip_address text,
    user_agent text,
    created_at timestamp without time zone DEFAULT now(),
    success boolean DEFAULT true,
    error_message text,
    "timestamp" timestamp without time zone DEFAULT now()
);


ALTER TABLE public.audit_logs OWNER TO neondb_owner;

--
-- Name: automation_workflows; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.automation_workflows (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    trigger jsonb NOT NULL,
    conditions jsonb,
    actions jsonb NOT NULL,
    status text DEFAULT 'active'::text,
    execution_count integer DEFAULT 0,
    last_executed_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.automation_workflows OWNER TO neondb_owner;

--
-- Name: backup_jobs; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.backup_jobs (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'pending'::text,
    backup_path text,
    file_size integer,
    duration integer,
    error_message text,
    tables_backed_up jsonb,
    retention_days integer DEFAULT 30,
    is_encrypted boolean DEFAULT true,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    expires_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.backup_jobs OWNER TO neondb_owner;

--
-- Name: builder_state; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.builder_state (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    website_id character varying NOT NULL,
    user_id character varying NOT NULL,
    current_content jsonb,
    undo_stack jsonb,
    redo_stack jsonb,
    selected_element text,
    viewport_mode text DEFAULT 'desktop'::text,
    last_saved_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.builder_state OWNER TO neondb_owner;

--
-- Name: campaigns; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.campaigns (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'draft'::text,
    content jsonb,
    targeting jsonb,
    schedule jsonb,
    metrics jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.campaigns OWNER TO neondb_owner;

--
-- Name: channel_integrations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.channel_integrations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    channel text NOT NULL,
    account_id text NOT NULL,
    access_token text,
    refresh_token text,
    shop_url text,
    is_active boolean DEFAULT true,
    sync_enabled boolean DEFAULT true,
    last_sync_at timestamp without time zone,
    sync_status text DEFAULT 'idle'::text,
    sync_error text,
    settings jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.channel_integrations OWNER TO neondb_owner;

--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.chat_messages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    room_id character varying NOT NULL,
    sender_id character varying NOT NULL,
    content text NOT NULL,
    type text DEFAULT 'text'::text,
    attachments jsonb,
    reply_to_id character varying,
    is_edited boolean DEFAULT false,
    edited_at timestamp without time zone,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.chat_messages OWNER TO neondb_owner;

--
-- Name: chat_room_members; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.chat_room_members (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    room_id character varying NOT NULL,
    user_id character varying NOT NULL,
    role text DEFAULT 'member'::text,
    last_read_at timestamp without time zone,
    notifications_enabled boolean DEFAULT true,
    joined_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.chat_room_members OWNER TO neondb_owner;

--
-- Name: chat_rooms; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.chat_rooms (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text,
    type text NOT NULL,
    community_id character varying,
    created_by character varying NOT NULL,
    icon text,
    last_message_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.chat_rooms OWNER TO neondb_owner;

--
-- Name: comments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.comments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    post_id character varying NOT NULL,
    user_id character varying,
    author_name text,
    author_email text,
    content text NOT NULL,
    status text DEFAULT 'pending'::text,
    parent_id character varying,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.comments OWNER TO neondb_owner;

--
-- Name: communities; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.communities (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    slug text NOT NULL,
    owner_id character varying NOT NULL,
    avatar text,
    cover text,
    is_private boolean DEFAULT false,
    member_count integer DEFAULT 0,
    settings jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.communities OWNER TO neondb_owner;

--
-- Name: community_members; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.community_members (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    community_id character varying NOT NULL,
    user_id character varying NOT NULL,
    role text DEFAULT 'member'::text,
    joined_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.community_members OWNER TO neondb_owner;

--
-- Name: compliance_reports; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.compliance_reports (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    report_type text NOT NULL,
    period jsonb NOT NULL,
    status text DEFAULT 'generating'::text,
    findings jsonb,
    recommendations jsonb,
    score numeric(5,2),
    report_url text,
    generated_at timestamp without time zone,
    expires_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.compliance_reports OWNER TO neondb_owner;

--
-- Name: content_moderation; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.content_moderation (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    content_type text NOT NULL,
    content_id character varying NOT NULL,
    status text DEFAULT 'pending'::text,
    moderator_id character varying,
    reason text,
    ai_score numeric(5,2),
    flags jsonb,
    review_notes text,
    reviewed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.content_moderation OWNER TO neondb_owner;

--
-- Name: content_roles; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.content_roles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    permissions jsonb NOT NULL,
    is_system boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.content_roles OWNER TO neondb_owner;

--
-- Name: content_schedule; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.content_schedule (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    post_id character varying NOT NULL,
    user_id character varying NOT NULL,
    scheduled_for timestamp without time zone NOT NULL,
    status text DEFAULT 'scheduled'::text,
    published_at timestamp without time zone,
    error_message text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.content_schedule OWNER TO neondb_owner;

--
-- Name: coupons; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.coupons (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    code text NOT NULL,
    description text,
    discount_type text NOT NULL,
    discount_value numeric(10,2) NOT NULL,
    min_purchase_amount numeric(10,2),
    max_discount_amount numeric(10,2),
    usage_limit integer,
    usage_count integer DEFAULT 0,
    per_customer_limit integer,
    starts_at timestamp without time zone,
    expires_at timestamp without time zone,
    is_active boolean DEFAULT true,
    applicable_to jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.coupons OWNER TO neondb_owner;

--
-- Name: crm_contacts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.crm_contacts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    email text NOT NULL,
    first_name text,
    last_name text,
    phone text,
    company text,
    job_title text,
    website text,
    address jsonb,
    tags jsonb,
    stage text DEFAULT 'lead'::text,
    source text,
    assigned_to character varying,
    lifetime_value numeric(10,2) DEFAULT 0,
    last_contacted_at timestamp without time zone,
    metadata jsonb,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.crm_contacts OWNER TO neondb_owner;

--
-- Name: crm_interactions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.crm_interactions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    contact_id character varying NOT NULL,
    user_id character varying NOT NULL,
    type text NOT NULL,
    subject text,
    description text,
    outcome text,
    scheduled_at timestamp without time zone,
    completed_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.crm_interactions OWNER TO neondb_owner;

--
-- Name: developer_payouts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.developer_payouts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    developer_id character varying NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'usd'::text,
    status text DEFAULT 'pending'::text,
    payment_method text,
    transaction_id text,
    period jsonb,
    plugins_sales jsonb,
    metadata jsonb,
    processed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.developer_payouts OWNER TO neondb_owner;

--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.email_verification_tokens (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    token text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    used boolean DEFAULT false,
    used_at timestamp without time zone,
    ip_address text,
    user_agent text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.email_verification_tokens OWNER TO neondb_owner;

--
-- Name: forum_replies; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.forum_replies (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    topic_id character varying NOT NULL,
    user_id character varying NOT NULL,
    content text NOT NULL,
    parent_reply_id character varying,
    vote_count integer DEFAULT 0,
    is_accepted boolean DEFAULT false,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.forum_replies OWNER TO neondb_owner;

--
-- Name: forum_topics; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.forum_topics (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    forum_id character varying NOT NULL,
    user_id character varying NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    content text NOT NULL,
    is_pinned boolean DEFAULT false,
    is_locked boolean DEFAULT false,
    view_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    vote_count integer DEFAULT 0,
    last_reply_at timestamp without time zone,
    last_reply_by character varying,
    tags jsonb,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.forum_topics OWNER TO neondb_owner;

--
-- Name: forum_votes; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.forum_votes (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    voteable_type text NOT NULL,
    voteable_id character varying NOT NULL,
    value integer NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.forum_votes OWNER TO neondb_owner;

--
-- Name: forums; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.forums (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    community_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    slug text NOT NULL,
    icon text,
    "position" integer DEFAULT 0,
    is_locked boolean DEFAULT false,
    topic_count integer DEFAULT 0,
    post_count integer DEFAULT 0,
    last_post_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.forums OWNER TO neondb_owner;

--
-- Name: funnel_entries; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.funnel_entries (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    funnel_id character varying NOT NULL,
    lead_id character varying,
    current_stage integer NOT NULL,
    metadata jsonb,
    entered_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    abandoned_at timestamp without time zone
);


ALTER TABLE public.funnel_entries OWNER TO neondb_owner;

--
-- Name: funnels; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.funnels (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    stages jsonb NOT NULL,
    status text DEFAULT 'active'::text,
    metrics jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.funnels OWNER TO neondb_owner;

--
-- Name: gdpr_requests; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.gdpr_requests (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    type text NOT NULL,
    status text DEFAULT 'pending'::text,
    requested_at timestamp without time zone DEFAULT now(),
    processed_at timestamp without time zone,
    completed_at timestamp without time zone,
    data_export_url text,
    expires_at timestamp without time zone,
    reason text,
    processor_notes text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.gdpr_requests OWNER TO neondb_owner;

--
-- Name: gift_card_transactions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.gift_card_transactions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    gift_card_id character varying NOT NULL,
    order_id character varying,
    amount numeric(10,2) NOT NULL,
    type text NOT NULL,
    balance_before numeric(10,2) NOT NULL,
    balance_after numeric(10,2) NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.gift_card_transactions OWNER TO neondb_owner;

--
-- Name: gift_cards; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.gift_cards (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    code text NOT NULL,
    initial_balance numeric(10,2) NOT NULL,
    current_balance numeric(10,2) NOT NULL,
    currency text DEFAULT 'usd'::text,
    purchased_by character varying,
    recipient_email text,
    recipient_name text,
    message text,
    expires_at timestamp without time zone,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.gift_cards OWNER TO neondb_owner;

--
-- Name: helpdesk_responses; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.helpdesk_responses (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    ticket_id character varying NOT NULL,
    user_id character varying NOT NULL,
    message text NOT NULL,
    is_internal boolean DEFAULT false,
    attachments jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.helpdesk_responses OWNER TO neondb_owner;

--
-- Name: helpdesk_tickets; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.helpdesk_tickets (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    subject text NOT NULL,
    description text NOT NULL,
    status text DEFAULT 'open'::text,
    priority text DEFAULT 'medium'::text,
    category text,
    assigned_to character varying,
    first_response_at timestamp without time zone,
    resolved_at timestamp without time zone,
    closed_at timestamp without time zone,
    tags jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.helpdesk_tickets OWNER TO neondb_owner;

--
-- Name: idempotency_keys; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.idempotency_keys (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    key text NOT NULL,
    user_id character varying,
    resource text NOT NULL,
    resource_id text,
    response_status integer,
    response_body jsonb,
    request_hash text,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.idempotency_keys OWNER TO neondb_owner;

--
-- Name: inventory_reservations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.inventory_reservations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    product_id character varying NOT NULL,
    order_id character varying NOT NULL,
    quantity integer NOT NULL,
    status text DEFAULT 'active'::text,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT inventory_reservations_quantity_check CHECK ((quantity > 0)),
    CONSTRAINT inventory_reservations_status_check CHECK ((status = ANY (ARRAY['active'::text, 'confirmed'::text, 'released'::text, 'expired'::text])))
);


ALTER TABLE public.inventory_reservations OWNER TO neondb_owner;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.invoices (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    order_id character varying,
    invoice_number text NOT NULL,
    status text DEFAULT 'draft'::text,
    due_date timestamp without time zone,
    subtotal numeric(10,2) NOT NULL,
    tax_total numeric(10,2) DEFAULT 0,
    total numeric(10,2) NOT NULL,
    currency text DEFAULT 'usd'::text,
    items jsonb NOT NULL,
    customer_info jsonb NOT NULL,
    notes text,
    pdf_url text,
    sent_at timestamp without time zone,
    paid_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.invoices OWNER TO neondb_owner;

--
-- Name: knowledge_base_articles; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.knowledge_base_articles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    author_id character varying NOT NULL,
    category_id character varying,
    title text NOT NULL,
    slug text NOT NULL,
    content text NOT NULL,
    excerpt text,
    status text DEFAULT 'draft'::text,
    view_count integer DEFAULT 0,
    helpful_count integer DEFAULT 0,
    unhelpful_count integer DEFAULT 0,
    tags jsonb,
    related_articles jsonb,
    metadata jsonb,
    published_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.knowledge_base_articles OWNER TO neondb_owner;

--
-- Name: knowledge_base_categories; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.knowledge_base_categories (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text,
    icon text,
    parent_id character varying,
    "position" integer DEFAULT 0,
    article_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.knowledge_base_categories OWNER TO neondb_owner;

--
-- Name: landing_pages; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.landing_pages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    template text,
    content jsonb,
    seo_title text,
    seo_description text,
    status text DEFAULT 'draft'::text,
    view_count integer DEFAULT 0,
    conversion_count integer DEFAULT 0,
    conversion_rate numeric(5,2) DEFAULT 0,
    metadata jsonb,
    published_at timestamp without time zone,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.landing_pages OWNER TO neondb_owner;

--
-- Name: leads; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.leads (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    email text NOT NULL,
    first_name text,
    last_name text,
    phone text,
    source text,
    status text DEFAULT 'new'::text,
    tags jsonb,
    custom_fields jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.leads OWNER TO neondb_owner;

--
-- Name: login_attempts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.login_attempts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    identifier text NOT NULL,
    ip_address text NOT NULL,
    successful boolean DEFAULT false,
    failure_reason text,
    user_agent text,
    attempted_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.login_attempts OWNER TO neondb_owner;

--
-- Name: magic_link_tokens; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.magic_link_tokens (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    token text NOT NULL,
    email text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    used boolean DEFAULT false,
    used_at timestamp without time zone,
    ip_address text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.magic_link_tokens OWNER TO neondb_owner;

--
-- Name: marketing_segments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.marketing_segments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    conditions jsonb NOT NULL,
    member_count integer DEFAULT 0,
    is_active boolean DEFAULT true,
    is_dynamic boolean DEFAULT true,
    last_calculated_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.marketing_segments OWNER TO neondb_owner;

--
-- Name: media; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.media (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    filename text NOT NULL,
    original_name text NOT NULL,
    mime_type text NOT NULL,
    size integer NOT NULL,
    url text NOT NULL,
    alt text,
    caption text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    encryption_iv text,
    encryption_auth_tag text,
    is_encrypted boolean DEFAULT false
);


ALTER TABLE public.media OWNER TO neondb_owner;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.messages (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    sender_id character varying NOT NULL,
    receiver_id character varying,
    community_id character varying,
    content text NOT NULL,
    type text DEFAULT 'text'::text,
    metadata jsonb,
    is_read boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    room_id character varying
);


ALTER TABLE public.messages OWNER TO neondb_owner;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.migrations (
    id character varying NOT NULL,
    name text NOT NULL,
    version integer NOT NULL,
    applied_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    checksum text,
    execution_time_ms integer
);


ALTER TABLE public.migrations OWNER TO neondb_owner;

--
-- Name: moderation_actions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.moderation_actions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    moderator_id character varying NOT NULL,
    target_type text NOT NULL,
    target_id character varying NOT NULL,
    target_user_id character varying,
    action text NOT NULL,
    reason text,
    duration integer,
    expires_at timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.moderation_actions OWNER TO neondb_owner;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.notifications (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    message text,
    data jsonb,
    is_read boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.notifications OWNER TO neondb_owner;

--
-- Name: oauth_providers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.oauth_providers (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    provider text NOT NULL,
    provider_id text NOT NULL,
    access_token text,
    refresh_token text,
    profile jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.oauth_providers OWNER TO neondb_owner;

--
-- Name: orders; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.orders (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    customer_email text NOT NULL,
    status text DEFAULT 'pending'::text,
    total numeric(10,2) NOT NULL,
    currency text DEFAULT 'usd'::text NOT NULL,
    stripe_payment_intent_id text,
    shipping_address jsonb,
    billing_address jsonb,
    items jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    customer_phone text,
    fulfillment_status text DEFAULT 'unfulfilled'::text,
    payment_status text DEFAULT 'pending'::text,
    subtotal numeric(10,2) NOT NULL,
    tax_total numeric(10,2) DEFAULT '0'::numeric,
    shipping_total numeric(10,2) DEFAULT '0'::numeric,
    discount_total numeric(10,2) DEFAULT '0'::numeric,
    idempotency_key text,
    discount_codes jsonb,
    tracking_number text,
    tracking_url text,
    notes text,
    internal_notes text,
    paid_at timestamp without time zone,
    fulfilled_at timestamp without time zone,
    cancelled_at timestamp without time zone,
    refunded_at timestamp without time zone,
    deleted_at timestamp without time zone,
    website_id character varying,
    order_number text,
    total_amount numeric(10,2),
    payment_method text
);


ALTER TABLE public.orders OWNER TO neondb_owner;

--
-- Name: password_history; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.password_history (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    password_hash text NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.password_history OWNER TO neondb_owner;

--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.password_reset_tokens (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    token text NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    used boolean DEFAULT false,
    used_at timestamp without time zone,
    ip_address text,
    user_agent text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.password_reset_tokens OWNER TO neondb_owner;

--
-- Name: payment_intents; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.payment_intents (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    stripe_payment_intent_id text,
    order_id character varying,
    user_id character varying,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'usd'::text,
    status text DEFAULT 'pending'::text,
    idempotency_key text NOT NULL,
    payment_method text,
    last_error text,
    retry_count integer DEFAULT 0,
    metadata jsonb,
    succeeded_at timestamp without time zone,
    failed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.payment_intents OWNER TO neondb_owner;

--
-- Name: permissions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.permissions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    resource text NOT NULL,
    action text NOT NULL,
    description text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.permissions OWNER TO neondb_owner;

--
-- Name: plugin_dependencies; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.plugin_dependencies (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    plugin_id character varying NOT NULL,
    depends_on_plugin_id character varying NOT NULL,
    min_version text,
    max_version text,
    is_required boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.plugin_dependencies OWNER TO neondb_owner;

--
-- Name: plugin_installations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.plugin_installations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    plugin_id character varying NOT NULL,
    version text NOT NULL,
    is_active boolean DEFAULT true,
    settings jsonb,
    installed_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.plugin_installations OWNER TO neondb_owner;

--
-- Name: plugin_licenses; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.plugin_licenses (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    plugin_id character varying NOT NULL,
    user_id character varying NOT NULL,
    type text NOT NULL,
    key text NOT NULL,
    activations integer DEFAULT 0,
    max_activations integer DEFAULT 1,
    expires_at timestamp without time zone,
    is_active boolean DEFAULT true,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.plugin_licenses OWNER TO neondb_owner;

--
-- Name: plugin_reviews; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.plugin_reviews (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    plugin_id character varying NOT NULL,
    user_id character varying NOT NULL,
    rating integer NOT NULL,
    title text,
    review text,
    helpful_count integer DEFAULT 0,
    verified boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT plugin_reviews_rating_check CHECK (((rating >= 1) AND (rating <= 5)))
);


ALTER TABLE public.plugin_reviews OWNER TO neondb_owner;

--
-- Name: plugins; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.plugins (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    developer_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    version text NOT NULL,
    category text,
    price numeric(10,2) DEFAULT '0'::numeric,
    icon text,
    screenshots jsonb,
    manifest jsonb,
    is_active boolean DEFAULT true,
    download_count integer DEFAULT 0,
    rating numeric(3,2) DEFAULT '0'::numeric,
    rating_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.plugins OWNER TO neondb_owner;

--
-- Name: posts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.posts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    content text,
    excerpt text,
    featured_image text,
    status text DEFAULT 'draft'::text,
    type text DEFAULT 'post'::text,
    language text DEFAULT 'en'::text,
    seo_title text,
    seo_description text,
    tags jsonb,
    metadata jsonb,
    published_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    deleted_at timestamp without time zone
);


ALTER TABLE public.posts OWNER TO neondb_owner;

--
-- Name: predictive_models; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.predictive_models (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    type text NOT NULL,
    version text NOT NULL,
    status text DEFAULT 'training'::text,
    accuracy numeric(5,2),
    parameters jsonb,
    training_data jsonb,
    trained_at timestamp without time zone,
    deployed_at timestamp without time zone,
    last_prediction_at timestamp without time zone,
    prediction_count integer DEFAULT 0,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.predictive_models OWNER TO neondb_owner;

--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.product_variants (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    product_id character varying NOT NULL,
    sku text NOT NULL,
    name text NOT NULL,
    options jsonb NOT NULL,
    price numeric(10,2),
    compare_at_price numeric(10,2),
    cost_per_item numeric(10,2),
    inventory integer DEFAULT 0 NOT NULL,
    low_stock_threshold integer DEFAULT 10,
    weight numeric(10,2),
    weight_unit text DEFAULT 'kg'::text,
    image text,
    barcode text,
    "position" integer DEFAULT 0,
    is_active boolean DEFAULT true,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    CONSTRAINT product_variants_compare_at_price_check CHECK (((compare_at_price IS NULL) OR (compare_at_price >= (0)::numeric))),
    CONSTRAINT product_variants_inventory_check CHECK ((inventory >= 0)),
    CONSTRAINT product_variants_price_check CHECK (((price IS NULL) OR (price >= (0)::numeric)))
);


ALTER TABLE public.product_variants OWNER TO neondb_owner;

--
-- Name: products; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.products (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    images jsonb,
    category text,
    sku text,
    inventory integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    compare_at_price numeric(10,2),
    cost_per_item numeric(10,2),
    low_stock_threshold integer DEFAULT 10,
    track_inventory boolean DEFAULT true,
    allow_backorder boolean DEFAULT false,
    weight numeric(10,2),
    weight_unit text DEFAULT 'kg'::text,
    taxable boolean DEFAULT true,
    tax_code text,
    deleted_at timestamp without time zone
);


ALTER TABLE public.products OWNER TO neondb_owner;

--
-- Name: referrals; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.referrals (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    affiliate_id character varying NOT NULL,
    referred_user_id character varying,
    referral_code text NOT NULL,
    status text DEFAULT 'pending'::text,
    commission_amount numeric(10,2) DEFAULT '0'::numeric,
    metadata jsonb,
    converted_at timestamp without time zone,
    paid_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.referrals OWNER TO neondb_owner;

--
-- Name: refunds; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.refunds (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    order_id character varying NOT NULL,
    stripe_refund_id text,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'usd'::text,
    reason text,
    status text DEFAULT 'pending'::text,
    inventory_restored boolean DEFAULT false,
    restored_items jsonb,
    metadata jsonb,
    initiated_by character varying,
    processed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.refunds OWNER TO neondb_owner;

--
-- Name: role_permissions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.role_permissions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    role text NOT NULL,
    permission_id character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.role_permissions OWNER TO neondb_owner;

--
-- Name: rss_feeds; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.rss_feeds (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    title text NOT NULL,
    description text,
    url text NOT NULL,
    filter jsonb,
    items_included jsonb,
    is_active boolean DEFAULT true,
    last_generated timestamp without time zone,
    subscriber_count integer DEFAULT 0,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.rss_feeds OWNER TO neondb_owner;

--
-- Name: security_events; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.security_events (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying,
    session_id character varying,
    event_type text NOT NULL,
    severity text NOT NULL,
    description text,
    ip_address text,
    user_agent text,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT security_events_severity_check CHECK ((severity = ANY (ARRAY['low'::text, 'medium'::text, 'high'::text, 'critical'::text])))
);


ALTER TABLE public.security_events OWNER TO neondb_owner;

--
-- Name: segment_members; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.segment_members (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    segment_id character varying NOT NULL,
    contact_id character varying,
    lead_id character varying,
    added_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.segment_members OWNER TO neondb_owner;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.sessions (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    refresh_token_hash text,
    expires_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    ip_address text,
    user_agent text,
    device_type text,
    device_fingerprint text,
    last_activity_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.sessions OWNER TO neondb_owner;

--
-- Name: shipping_providers; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.shipping_providers (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    account_id text,
    api_key text,
    api_secret text,
    is_active boolean DEFAULT true,
    is_default boolean DEFAULT false,
    settings jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.shipping_providers OWNER TO neondb_owner;

--
-- Name: shipping_rates; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.shipping_rates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    provider_id character varying NOT NULL,
    name text NOT NULL,
    service_code text NOT NULL,
    countries jsonb,
    weight_min numeric(10,2),
    weight_max numeric(10,2),
    base_rate numeric(10,2) NOT NULL,
    per_weight_rate numeric(10,2) DEFAULT 0,
    delivery_days_min integer,
    delivery_days_max integer,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.shipping_rates OWNER TO neondb_owner;

--
-- Name: social_media_connections; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.social_media_connections (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    platform text NOT NULL,
    account_id text NOT NULL,
    account_name text,
    access_token text,
    refresh_token text,
    expires_at timestamp without time zone,
    is_active boolean DEFAULT true,
    permissions jsonb,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.social_media_connections OWNER TO neondb_owner;

--
-- Name: ssl_certificates; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.ssl_certificates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    domain text NOT NULL,
    provider text DEFAULT 'letsencrypt'::text,
    certificate text,
    private_key text,
    chain_certificate text,
    status text DEFAULT 'pending'::text,
    issued_at timestamp without time zone,
    expires_at timestamp without time zone,
    auto_renew boolean DEFAULT true,
    last_renewal_attempt timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.ssl_certificates OWNER TO neondb_owner;

--
-- Name: sso_configurations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.sso_configurations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    provider text NOT NULL,
    name text NOT NULL,
    entity_id text,
    sso_url text,
    certificate text,
    client_id text,
    client_secret text,
    scopes jsonb,
    is_active boolean DEFAULT true,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.sso_configurations OWNER TO neondb_owner;

--
-- Name: staging_environments; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.staging_environments (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    website_id character varying NOT NULL,
    name text NOT NULL,
    url text,
    content jsonb,
    settings jsonb,
    status text DEFAULT 'active'::text,
    deployed_by character varying,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.staging_environments OWNER TO neondb_owner;

--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.subscription_plans (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    description text,
    price numeric(10,2) NOT NULL,
    billing_period text NOT NULL,
    trial_days integer DEFAULT 0,
    features jsonb,
    limits jsonb,
    stripe_price_id text,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.subscription_plans OWNER TO neondb_owner;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.subscriptions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    plan text NOT NULL,
    status text NOT NULL,
    stripe_subscription_id text,
    stripe_price_id text,
    current_period_start timestamp without time zone,
    current_period_end timestamp without time zone,
    cancel_at_period_end boolean DEFAULT false,
    trial_end timestamp without time zone,
    metadata jsonb,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.subscriptions OWNER TO neondb_owner;

--
-- Name: tax_rules; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.tax_rules (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    country text NOT NULL,
    state text,
    zip_code text,
    rate numeric(5,2) NOT NULL,
    is_compound boolean DEFAULT false,
    priority integer DEFAULT 0,
    applicable_product_types jsonb,
    is_active boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.tax_rules OWNER TO neondb_owner;

--
-- Name: two_factor_attempts; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.two_factor_attempts (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    ip_address text NOT NULL,
    user_agent text,
    successful boolean DEFAULT false,
    failure_reason text,
    attempted_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.two_factor_attempts OWNER TO neondb_owner;

--
-- Name: user_content_roles; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.user_content_roles (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    role_id character varying NOT NULL,
    scope text,
    scope_id character varying,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_content_roles OWNER TO neondb_owner;

--
-- Name: user_permissions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.user_permissions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    permission_id character varying NOT NULL,
    granted boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.user_permissions OWNER TO neondb_owner;

--
-- Name: users; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.users (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    password text NOT NULL,
    first_name text,
    last_name text,
    avatar text,
    role text DEFAULT 'user'::text NOT NULL,
    subscription_tier text DEFAULT 'free'::text,
    stripe_customer_id text,
    stripe_subscription_id text,
    is_email_verified boolean DEFAULT false,
    two_factor_enabled boolean DEFAULT false,
    two_factor_secret text,
    two_factor_backup_codes text,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    deleted_at timestamp without time zone
);


ALTER TABLE public.users OWNER TO neondb_owner;

--
-- Name: webhook_events; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.webhook_events (
    id text NOT NULL,
    type text NOT NULL,
    processed boolean DEFAULT false,
    processed_at timestamp without time zone,
    payload jsonb,
    error text,
    retry_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.webhook_events OWNER TO neondb_owner;

--
-- Name: webhook_integrations; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.webhook_integrations (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    website_id character varying,
    name text NOT NULL,
    url text NOT NULL,
    events jsonb NOT NULL,
    headers jsonb,
    is_active boolean DEFAULT true,
    secret text,
    last_triggered_at timestamp without time zone,
    success_count integer DEFAULT 0,
    failure_count integer DEFAULT 0,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.webhook_integrations OWNER TO neondb_owner;

--
-- Name: webhook_retries; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.webhook_retries (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    webhook_event_id character varying NOT NULL,
    attempt integer DEFAULT 1 NOT NULL,
    max_attempts integer DEFAULT 5 NOT NULL,
    next_retry_at timestamp without time zone NOT NULL,
    last_error text,
    last_status_code integer,
    last_attempt_at timestamp without time zone,
    status text DEFAULT 'pending'::text NOT NULL,
    backoff_seconds integer DEFAULT 60 NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.webhook_retries OWNER TO neondb_owner;

--
-- Name: website_templates; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.website_templates (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    creator_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    category text NOT NULL,
    industry text,
    thumbnail text,
    screenshots jsonb,
    content jsonb NOT NULL,
    settings jsonb,
    price numeric(10,2) DEFAULT 0,
    is_free boolean DEFAULT true,
    is_premium boolean DEFAULT false,
    download_count integer DEFAULT 0,
    rating numeric(3,2) DEFAULT 0,
    rating_count integer DEFAULT 0,
    is_active boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    tags jsonb,
    metadata jsonb,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.website_templates OWNER TO neondb_owner;

--
-- Name: website_versions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.website_versions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    website_id character varying NOT NULL,
    version integer NOT NULL,
    content jsonb,
    settings jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.website_versions OWNER TO neondb_owner;

--
-- Name: websites; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.websites (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    user_id character varying NOT NULL,
    name text NOT NULL,
    description text,
    domain text,
    template text,
    content jsonb,
    settings jsonb,
    status text DEFAULT 'draft'::text,
    version integer DEFAULT 1,
    is_public boolean DEFAULT false,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    deleted_at timestamp without time zone
);


ALTER TABLE public.websites OWNER TO neondb_owner;

--
-- Name: workflow_executions; Type: TABLE; Schema: public; Owner: neondb_owner
--

CREATE TABLE public.workflow_executions (
    id character varying DEFAULT gen_random_uuid() NOT NULL,
    workflow_id character varying NOT NULL,
    status text DEFAULT 'pending'::text,
    trigger_data jsonb,
    result jsonb,
    error_message text,
    started_at timestamp without time zone DEFAULT now(),
    completed_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.workflow_executions OWNER TO neondb_owner;

--
-- Name: __drizzle_migrations id; Type: DEFAULT; Schema: drizzle; Owner: neondb_owner
--

ALTER TABLE ONLY drizzle.__drizzle_migrations ALTER COLUMN id SET DEFAULT nextval('drizzle.__drizzle_migrations_id_seq'::regclass);


--
-- Data for Name: __drizzle_migrations; Type: TABLE DATA; Schema: drizzle; Owner: neondb_owner
--

COPY drizzle.__drizzle_migrations (id, hash, created_at) FROM stdin;
\.


--
-- Data for Name: ab_test_participants; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.ab_test_participants (id, test_id, participant_id, variant, converted, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: ab_tests; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.ab_tests (id, user_id, name, description, resource_type, resource_id, variants, status, winner_variant, start_date, end_date, metrics, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: account_lockouts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.account_lockouts (id, user_id, locked_at, locked_until, lock_reason, failed_attempts, last_attempt_at, unlocked, unlocked_at, created_at) FROM stdin;
\.


--
-- Data for Name: affiliates; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.affiliates (id, user_id, code, commission_rate, total_earnings, total_referrals, status, payment_info, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_cost_tracking; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.ai_cost_tracking (id, user_id, provider, model, feature, prompt_tokens, completion_tokens, total_tokens, estimated_cost, request_duration_ms, success, error_message, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: ai_predictions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.ai_predictions (id, model_id, user_id, input_data, prediction, confidence, actual_outcome, was_accurate, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: ai_provider_failover; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.ai_provider_failover (id, provider, state, failure_count, consecutive_failures, last_failure_at, last_success_at, last_health_check_at, is_available, latency_ms, error_message, cooldown_until, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_rate_limits; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.ai_rate_limits (id, user_id, window_start, request_count, last_request_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ai_training_data; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.ai_training_data (id, user_id, data_type, input, output, feedback, quality_score, is_approved, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: analytics; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.analytics (id, user_id, event_type, event_name, resource_type, resource_id, value, metadata, user_agent, ip_address, referrer, created_at) FROM stdin;
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.api_keys (id, user_id, name, key_hash, key_prefix, last_used_at, expires_at, revoked_at, scopes, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.audit_logs (id, user_id, action, resource, resource_id, details, ip_address, user_agent, created_at, success, error_message, "timestamp") FROM stdin;
\.


--
-- Data for Name: automation_workflows; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.automation_workflows (id, user_id, name, description, trigger, conditions, actions, status, execution_count, last_executed_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: backup_jobs; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.backup_jobs (id, type, status, backup_path, file_size, duration, error_message, tables_backed_up, retention_days, is_encrypted, started_at, completed_at, expires_at, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: builder_state; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.builder_state (id, website_id, user_id, current_content, undo_stack, redo_stack, selected_element, viewport_mode, last_saved_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: campaigns; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.campaigns (id, user_id, name, type, status, content, targeting, schedule, metrics, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: channel_integrations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.channel_integrations (id, user_id, channel, account_id, access_token, refresh_token, shop_url, is_active, sync_enabled, last_sync_at, sync_status, sync_error, settings, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.chat_messages (id, room_id, sender_id, content, type, attachments, reply_to_id, is_edited, edited_at, deleted_at, created_at) FROM stdin;
\.


--
-- Data for Name: chat_room_members; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.chat_room_members (id, room_id, user_id, role, last_read_at, notifications_enabled, joined_at) FROM stdin;
\.


--
-- Data for Name: chat_rooms; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.chat_rooms (id, name, type, community_id, created_by, icon, last_message_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: comments; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.comments (id, post_id, user_id, author_name, author_email, content, status, parent_id, created_at) FROM stdin;
\.


--
-- Data for Name: communities; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.communities (id, name, description, slug, owner_id, avatar, cover, is_private, member_count, settings, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: community_members; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.community_members (id, community_id, user_id, role, joined_at) FROM stdin;
\.


--
-- Data for Name: compliance_reports; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.compliance_reports (id, user_id, report_type, period, status, findings, recommendations, score, report_url, generated_at, expires_at, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: content_moderation; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.content_moderation (id, content_type, content_id, status, moderator_id, reason, ai_score, flags, review_notes, reviewed_at, created_at) FROM stdin;
\.


--
-- Data for Name: content_roles; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.content_roles (id, name, description, permissions, is_system, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: content_schedule; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.content_schedule (id, post_id, user_id, scheduled_for, status, published_at, error_message, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: coupons; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.coupons (id, user_id, code, description, discount_type, discount_value, min_purchase_amount, max_discount_amount, usage_limit, usage_count, per_customer_limit, starts_at, expires_at, is_active, applicable_to, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: crm_contacts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.crm_contacts (id, user_id, email, first_name, last_name, phone, company, job_title, website, address, tags, stage, source, assigned_to, lifetime_value, last_contacted_at, metadata, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: crm_interactions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.crm_interactions (id, contact_id, user_id, type, subject, description, outcome, scheduled_at, completed_at, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: developer_payouts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.developer_payouts (id, developer_id, amount, currency, status, payment_method, transaction_id, period, plugins_sales, metadata, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.email_verification_tokens (id, user_id, token, expires_at, used, used_at, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: forum_replies; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.forum_replies (id, topic_id, user_id, content, parent_reply_id, vote_count, is_accepted, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forum_topics; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.forum_topics (id, forum_id, user_id, title, slug, content, is_pinned, is_locked, view_count, reply_count, vote_count, last_reply_at, last_reply_by, tags, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: forum_votes; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.forum_votes (id, user_id, voteable_type, voteable_id, value, created_at) FROM stdin;
\.


--
-- Data for Name: forums; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.forums (id, community_id, name, description, slug, icon, "position", is_locked, topic_count, post_count, last_post_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: funnel_entries; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.funnel_entries (id, funnel_id, lead_id, current_stage, metadata, entered_at, completed_at, abandoned_at) FROM stdin;
\.


--
-- Data for Name: funnels; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.funnels (id, user_id, name, description, stages, status, metrics, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: gdpr_requests; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.gdpr_requests (id, user_id, type, status, requested_at, processed_at, completed_at, data_export_url, expires_at, reason, processor_notes, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: gift_card_transactions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.gift_card_transactions (id, gift_card_id, order_id, amount, type, balance_before, balance_after, created_at) FROM stdin;
\.


--
-- Data for Name: gift_cards; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.gift_cards (id, code, initial_balance, current_balance, currency, purchased_by, recipient_email, recipient_name, message, expires_at, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: helpdesk_responses; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.helpdesk_responses (id, ticket_id, user_id, message, is_internal, attachments, created_at) FROM stdin;
\.


--
-- Data for Name: helpdesk_tickets; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.helpdesk_tickets (id, user_id, subject, description, status, priority, category, assigned_to, first_response_at, resolved_at, closed_at, tags, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: idempotency_keys; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.idempotency_keys (id, key, user_id, resource, resource_id, response_status, response_body, request_hash, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: inventory_reservations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.inventory_reservations (id, product_id, order_id, quantity, status, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.invoices (id, user_id, order_id, invoice_number, status, due_date, subtotal, tax_total, total, currency, items, customer_info, notes, pdf_url, sent_at, paid_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_base_articles; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.knowledge_base_articles (id, author_id, category_id, title, slug, content, excerpt, status, view_count, helpful_count, unhelpful_count, tags, related_articles, metadata, published_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: knowledge_base_categories; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.knowledge_base_categories (id, name, slug, description, icon, parent_id, "position", article_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: landing_pages; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.landing_pages (id, user_id, name, slug, template, content, seo_title, seo_description, status, view_count, conversion_count, conversion_rate, metadata, published_at, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: leads; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.leads (id, user_id, email, first_name, last_name, phone, source, status, tags, custom_fields, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: login_attempts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.login_attempts (id, identifier, ip_address, successful, failure_reason, user_agent, attempted_at) FROM stdin;
\.


--
-- Data for Name: magic_link_tokens; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.magic_link_tokens (id, user_id, token, email, expires_at, used, used_at, ip_address, created_at) FROM stdin;
\.


--
-- Data for Name: marketing_segments; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.marketing_segments (id, user_id, name, description, conditions, member_count, is_active, is_dynamic, last_calculated_at, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: media; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.media (id, user_id, filename, original_name, mime_type, size, url, alt, caption, metadata, created_at, encryption_iv, encryption_auth_tag, is_encrypted) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.messages (id, sender_id, receiver_id, community_id, content, type, metadata, is_read, created_at, room_id) FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.migrations (id, name, version, applied_at, checksum, execution_time_ms) FROM stdin;
migration_2_add_performance_indexes	add_performance_indexes	2	2025-10-10 12:41:52.471401	54b7ac57f6db17a2f79d9222304d985b70616ba658cff2ed750c143f9d7c369c	359
\.


--
-- Data for Name: moderation_actions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.moderation_actions (id, moderator_id, target_type, target_id, target_user_id, action, reason, duration, expires_at, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.notifications (id, user_id, type, title, message, data, is_read, created_at) FROM stdin;
\.


--
-- Data for Name: oauth_providers; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.oauth_providers (id, user_id, provider, provider_id, access_token, refresh_token, profile, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.orders (id, user_id, customer_email, status, total, currency, stripe_payment_intent_id, shipping_address, billing_address, items, metadata, created_at, updated_at, customer_phone, fulfillment_status, payment_status, subtotal, tax_total, shipping_total, discount_total, idempotency_key, discount_codes, tracking_number, tracking_url, notes, internal_notes, paid_at, fulfilled_at, cancelled_at, refunded_at, deleted_at, website_id, order_number, total_amount, payment_method) FROM stdin;
\.


--
-- Data for Name: password_history; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.password_history (id, user_id, password_hash, created_at) FROM stdin;
\.


--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.password_reset_tokens (id, user_id, token, expires_at, used, used_at, ip_address, user_agent, created_at) FROM stdin;
\.


--
-- Data for Name: payment_intents; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.payment_intents (id, stripe_payment_intent_id, order_id, user_id, amount, currency, status, idempotency_key, payment_method, last_error, retry_count, metadata, succeeded_at, failed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.permissions (id, name, resource, action, description, created_at) FROM stdin;
\.


--
-- Data for Name: plugin_dependencies; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.plugin_dependencies (id, plugin_id, depends_on_plugin_id, min_version, max_version, is_required, created_at) FROM stdin;
\.


--
-- Data for Name: plugin_installations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.plugin_installations (id, user_id, plugin_id, version, is_active, settings, installed_at) FROM stdin;
\.


--
-- Data for Name: plugin_licenses; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.plugin_licenses (id, plugin_id, user_id, type, key, activations, max_activations, expires_at, is_active, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plugin_reviews; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.plugin_reviews (id, plugin_id, user_id, rating, title, review, helpful_count, verified, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plugins; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.plugins (id, developer_id, name, description, version, category, price, icon, screenshots, manifest, is_active, download_count, rating, rating_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.posts (id, user_id, title, slug, content, excerpt, featured_image, status, type, language, seo_title, seo_description, tags, metadata, published_at, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: predictive_models; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.predictive_models (id, name, type, version, status, accuracy, parameters, training_data, trained_at, deployed_at, last_prediction_at, prediction_count, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.product_variants (id, product_id, sku, name, options, price, compare_at_price, cost_per_item, inventory, low_stock_threshold, weight, weight_unit, image, barcode, "position", is_active, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.products (id, user_id, name, description, price, images, category, sku, inventory, is_active, metadata, created_at, updated_at, compare_at_price, cost_per_item, low_stock_threshold, track_inventory, allow_backorder, weight, weight_unit, taxable, tax_code, deleted_at) FROM stdin;
\.


--
-- Data for Name: referrals; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.referrals (id, affiliate_id, referred_user_id, referral_code, status, commission_amount, metadata, converted_at, paid_at, created_at) FROM stdin;
\.


--
-- Data for Name: refunds; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.refunds (id, order_id, stripe_refund_id, amount, currency, reason, status, inventory_restored, restored_items, metadata, initiated_by, processed_at, created_at) FROM stdin;
\.


--
-- Data for Name: role_permissions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.role_permissions (id, role, permission_id, created_at) FROM stdin;
\.


--
-- Data for Name: rss_feeds; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.rss_feeds (id, user_id, title, description, url, filter, items_included, is_active, last_generated, subscriber_count, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: security_events; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.security_events (id, user_id, session_id, event_type, severity, description, ip_address, user_agent, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: segment_members; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.segment_members (id, segment_id, contact_id, lead_id, added_at) FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.sessions (id, user_id, refresh_token_hash, expires_at, created_at, updated_at, ip_address, user_agent, device_type, device_fingerprint, last_activity_at) FROM stdin;
\.


--
-- Data for Name: shipping_providers; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.shipping_providers (id, user_id, name, account_id, api_key, api_secret, is_active, is_default, settings, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: shipping_rates; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.shipping_rates (id, provider_id, name, service_code, countries, weight_min, weight_max, base_rate, per_weight_rate, delivery_days_min, delivery_days_max, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: social_media_connections; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.social_media_connections (id, user_id, platform, account_id, account_name, access_token, refresh_token, expires_at, is_active, permissions, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: ssl_certificates; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.ssl_certificates (id, user_id, domain, provider, certificate, private_key, chain_certificate, status, issued_at, expires_at, auto_renew, last_renewal_attempt, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: sso_configurations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.sso_configurations (id, user_id, provider, name, entity_id, sso_url, certificate, client_id, client_secret, scopes, is_active, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: staging_environments; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.staging_environments (id, website_id, name, url, content, settings, status, deployed_by, expires_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: subscription_plans; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.subscription_plans (id, name, description, price, billing_period, trial_days, features, limits, stripe_price_id, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.subscriptions (id, user_id, plan, status, stripe_subscription_id, stripe_price_id, current_period_start, current_period_end, cancel_at_period_end, trial_end, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tax_rules; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.tax_rules (id, user_id, name, country, state, zip_code, rate, is_compound, priority, applicable_product_types, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: two_factor_attempts; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.two_factor_attempts (id, user_id, ip_address, user_agent, successful, failure_reason, attempted_at) FROM stdin;
\.


--
-- Data for Name: user_content_roles; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.user_content_roles (id, user_id, role_id, scope, scope_id, created_at) FROM stdin;
\.


--
-- Data for Name: user_permissions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.user_permissions (id, user_id, permission_id, granted, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.users (id, username, email, password, first_name, last_name, avatar, role, subscription_tier, stripe_customer_id, stripe_subscription_id, is_email_verified, two_factor_enabled, two_factor_secret, two_factor_backup_codes, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.webhook_events (id, type, processed, processed_at, payload, error, retry_count, created_at) FROM stdin;
\.


--
-- Data for Name: webhook_integrations; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.webhook_integrations (id, user_id, website_id, name, url, events, headers, is_active, secret, last_triggered_at, success_count, failure_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: webhook_retries; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.webhook_retries (id, webhook_event_id, attempt, max_attempts, next_retry_at, last_error, last_status_code, last_attempt_at, status, backoff_seconds, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: website_templates; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.website_templates (id, creator_id, name, description, category, industry, thumbnail, screenshots, content, settings, price, is_free, is_premium, download_count, rating, rating_count, is_active, is_featured, tags, metadata, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: website_versions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.website_versions (id, website_id, version, content, settings, created_at) FROM stdin;
\.


--
-- Data for Name: websites; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.websites (id, user_id, name, description, domain, template, content, settings, status, version, is_public, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- Data for Name: workflow_executions; Type: TABLE DATA; Schema: public; Owner: neondb_owner
--

COPY public.workflow_executions (id, workflow_id, status, trigger_data, result, error_message, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Name: __drizzle_migrations_id_seq; Type: SEQUENCE SET; Schema: drizzle; Owner: neondb_owner
--

SELECT pg_catalog.setval('drizzle.__drizzle_migrations_id_seq', 1, false);


--
-- Name: __drizzle_migrations __drizzle_migrations_pkey; Type: CONSTRAINT; Schema: drizzle; Owner: neondb_owner
--

ALTER TABLE ONLY drizzle.__drizzle_migrations
    ADD CONSTRAINT __drizzle_migrations_pkey PRIMARY KEY (id);


--
-- Name: ab_test_participants ab_test_participants_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ab_test_participants
    ADD CONSTRAINT ab_test_participants_pkey PRIMARY KEY (id);


--
-- Name: ab_tests ab_tests_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ab_tests
    ADD CONSTRAINT ab_tests_pkey PRIMARY KEY (id);


--
-- Name: account_lockouts account_lockouts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.account_lockouts
    ADD CONSTRAINT account_lockouts_pkey PRIMARY KEY (id);


--
-- Name: account_lockouts account_lockouts_user_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.account_lockouts
    ADD CONSTRAINT account_lockouts_user_id_unique UNIQUE (user_id);


--
-- Name: affiliates affiliates_code_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.affiliates
    ADD CONSTRAINT affiliates_code_unique UNIQUE (code);


--
-- Name: affiliates affiliates_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.affiliates
    ADD CONSTRAINT affiliates_pkey PRIMARY KEY (id);


--
-- Name: ai_cost_tracking ai_cost_tracking_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ai_cost_tracking
    ADD CONSTRAINT ai_cost_tracking_pkey PRIMARY KEY (id);


--
-- Name: ai_predictions ai_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ai_predictions
    ADD CONSTRAINT ai_predictions_pkey PRIMARY KEY (id);


--
-- Name: ai_provider_failover ai_provider_failover_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ai_provider_failover
    ADD CONSTRAINT ai_provider_failover_pkey PRIMARY KEY (id);


--
-- Name: ai_rate_limits ai_rate_limits_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ai_rate_limits
    ADD CONSTRAINT ai_rate_limits_pkey PRIMARY KEY (id);


--
-- Name: ai_training_data ai_training_data_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ai_training_data
    ADD CONSTRAINT ai_training_data_pkey PRIMARY KEY (id);


--
-- Name: analytics analytics_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.analytics
    ADD CONSTRAINT analytics_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: automation_workflows automation_workflows_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.automation_workflows
    ADD CONSTRAINT automation_workflows_pkey PRIMARY KEY (id);


--
-- Name: backup_jobs backup_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_pkey PRIMARY KEY (id);


--
-- Name: builder_state builder_state_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.builder_state
    ADD CONSTRAINT builder_state_pkey PRIMARY KEY (id);


--
-- Name: campaigns campaigns_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_pkey PRIMARY KEY (id);


--
-- Name: channel_integrations channel_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.channel_integrations
    ADD CONSTRAINT channel_integrations_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: chat_room_members chat_room_members_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_room_members
    ADD CONSTRAINT chat_room_members_pkey PRIMARY KEY (id);


--
-- Name: chat_rooms chat_rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_rooms
    ADD CONSTRAINT chat_rooms_pkey PRIMARY KEY (id);


--
-- Name: comments comments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_pkey PRIMARY KEY (id);


--
-- Name: communities communities_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.communities
    ADD CONSTRAINT communities_pkey PRIMARY KEY (id);


--
-- Name: communities communities_slug_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.communities
    ADD CONSTRAINT communities_slug_unique UNIQUE (slug);


--
-- Name: community_members community_members_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.community_members
    ADD CONSTRAINT community_members_pkey PRIMARY KEY (id);


--
-- Name: compliance_reports compliance_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.compliance_reports
    ADD CONSTRAINT compliance_reports_pkey PRIMARY KEY (id);


--
-- Name: content_moderation content_moderation_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.content_moderation
    ADD CONSTRAINT content_moderation_pkey PRIMARY KEY (id);


--
-- Name: content_roles content_roles_name_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.content_roles
    ADD CONSTRAINT content_roles_name_key UNIQUE (name);


--
-- Name: content_roles content_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.content_roles
    ADD CONSTRAINT content_roles_pkey PRIMARY KEY (id);


--
-- Name: content_schedule content_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.content_schedule
    ADD CONSTRAINT content_schedule_pkey PRIMARY KEY (id);


--
-- Name: coupons coupons_code_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_code_unique UNIQUE (code);


--
-- Name: coupons coupons_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_pkey PRIMARY KEY (id);


--
-- Name: crm_contacts crm_contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.crm_contacts
    ADD CONSTRAINT crm_contacts_pkey PRIMARY KEY (id);


--
-- Name: crm_interactions crm_interactions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.crm_interactions
    ADD CONSTRAINT crm_interactions_pkey PRIMARY KEY (id);


--
-- Name: developer_payouts developer_payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.developer_payouts
    ADD CONSTRAINT developer_payouts_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_token_unique UNIQUE (token);


--
-- Name: forum_replies forum_replies_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.forum_replies
    ADD CONSTRAINT forum_replies_pkey PRIMARY KEY (id);


--
-- Name: forum_topics forum_topics_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.forum_topics
    ADD CONSTRAINT forum_topics_pkey PRIMARY KEY (id);


--
-- Name: forum_votes forum_votes_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.forum_votes
    ADD CONSTRAINT forum_votes_pkey PRIMARY KEY (id);


--
-- Name: forums forums_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.forums
    ADD CONSTRAINT forums_pkey PRIMARY KEY (id);


--
-- Name: funnel_entries funnel_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.funnel_entries
    ADD CONSTRAINT funnel_entries_pkey PRIMARY KEY (id);


--
-- Name: funnels funnels_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.funnels
    ADD CONSTRAINT funnels_pkey PRIMARY KEY (id);


--
-- Name: gdpr_requests gdpr_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gdpr_requests
    ADD CONSTRAINT gdpr_requests_pkey PRIMARY KEY (id);


--
-- Name: gift_card_transactions gift_card_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gift_card_transactions
    ADD CONSTRAINT gift_card_transactions_pkey PRIMARY KEY (id);


--
-- Name: gift_cards gift_cards_code_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_code_unique UNIQUE (code);


--
-- Name: gift_cards gift_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_pkey PRIMARY KEY (id);


--
-- Name: helpdesk_responses helpdesk_responses_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.helpdesk_responses
    ADD CONSTRAINT helpdesk_responses_pkey PRIMARY KEY (id);


--
-- Name: helpdesk_tickets helpdesk_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.helpdesk_tickets
    ADD CONSTRAINT helpdesk_tickets_pkey PRIMARY KEY (id);


--
-- Name: idempotency_keys idempotency_keys_key_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_key_key UNIQUE (key);


--
-- Name: idempotency_keys idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_pkey PRIMARY KEY (id);


--
-- Name: inventory_reservations inventory_reservations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: knowledge_base_articles knowledge_base_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.knowledge_base_articles
    ADD CONSTRAINT knowledge_base_articles_pkey PRIMARY KEY (id);


--
-- Name: knowledge_base_articles knowledge_base_articles_slug_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.knowledge_base_articles
    ADD CONSTRAINT knowledge_base_articles_slug_key UNIQUE (slug);


--
-- Name: knowledge_base_categories knowledge_base_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.knowledge_base_categories
    ADD CONSTRAINT knowledge_base_categories_pkey PRIMARY KEY (id);


--
-- Name: knowledge_base_categories knowledge_base_categories_slug_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.knowledge_base_categories
    ADD CONSTRAINT knowledge_base_categories_slug_key UNIQUE (slug);


--
-- Name: landing_pages landing_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.landing_pages
    ADD CONSTRAINT landing_pages_pkey PRIMARY KEY (id);


--
-- Name: landing_pages landing_pages_slug_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.landing_pages
    ADD CONSTRAINT landing_pages_slug_key UNIQUE (slug);


--
-- Name: leads leads_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_pkey PRIMARY KEY (id);


--
-- Name: login_attempts login_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.login_attempts
    ADD CONSTRAINT login_attempts_pkey PRIMARY KEY (id);


--
-- Name: magic_link_tokens magic_link_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.magic_link_tokens
    ADD CONSTRAINT magic_link_tokens_pkey PRIMARY KEY (id);


--
-- Name: magic_link_tokens magic_link_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.magic_link_tokens
    ADD CONSTRAINT magic_link_tokens_token_unique UNIQUE (token);


--
-- Name: marketing_segments marketing_segments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.marketing_segments
    ADD CONSTRAINT marketing_segments_pkey PRIMARY KEY (id);


--
-- Name: media media_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_version_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_version_key UNIQUE (version);


--
-- Name: moderation_actions moderation_actions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.moderation_actions
    ADD CONSTRAINT moderation_actions_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: oauth_providers oauth_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.oauth_providers
    ADD CONSTRAINT oauth_providers_pkey PRIMARY KEY (id);


--
-- Name: orders orders_idempotency_key_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_idempotency_key_unique UNIQUE (idempotency_key);


--
-- Name: orders orders_order_number_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_order_number_key UNIQUE (order_number);


--
-- Name: orders orders_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_pkey PRIMARY KEY (id);


--
-- Name: orders orders_stripe_payment_intent_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_stripe_payment_intent_id_unique UNIQUE (stripe_payment_intent_id);


--
-- Name: password_history password_history_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_history
    ADD CONSTRAINT password_history_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_token_unique UNIQUE (token);


--
-- Name: payment_intents payment_intents_idempotency_key_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payment_intents
    ADD CONSTRAINT payment_intents_idempotency_key_unique UNIQUE (idempotency_key);


--
-- Name: payment_intents payment_intents_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payment_intents
    ADD CONSTRAINT payment_intents_pkey PRIMARY KEY (id);


--
-- Name: payment_intents payment_intents_stripe_payment_intent_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payment_intents
    ADD CONSTRAINT payment_intents_stripe_payment_intent_id_unique UNIQUE (stripe_payment_intent_id);


--
-- Name: permissions permissions_name_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_name_unique UNIQUE (name);


--
-- Name: permissions permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_pkey PRIMARY KEY (id);


--
-- Name: plugin_dependencies plugin_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugin_dependencies
    ADD CONSTRAINT plugin_dependencies_pkey PRIMARY KEY (id);


--
-- Name: plugin_installations plugin_installations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugin_installations
    ADD CONSTRAINT plugin_installations_pkey PRIMARY KEY (id);


--
-- Name: plugin_licenses plugin_licenses_key_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugin_licenses
    ADD CONSTRAINT plugin_licenses_key_key UNIQUE (key);


--
-- Name: plugin_licenses plugin_licenses_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugin_licenses
    ADD CONSTRAINT plugin_licenses_pkey PRIMARY KEY (id);


--
-- Name: plugin_reviews plugin_reviews_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugin_reviews
    ADD CONSTRAINT plugin_reviews_pkey PRIMARY KEY (id);


--
-- Name: plugins plugins_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugins
    ADD CONSTRAINT plugins_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: posts posts_slug_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_slug_unique UNIQUE (slug);


--
-- Name: predictive_models predictive_models_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.predictive_models
    ADD CONSTRAINT predictive_models_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_sku_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_sku_key UNIQUE (sku);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: products products_sku_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_sku_unique UNIQUE (sku);


--
-- Name: referrals referrals_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_pkey PRIMARY KEY (id);


--
-- Name: refunds refunds_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_pkey PRIMARY KEY (id);


--
-- Name: refunds refunds_stripe_refund_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_stripe_refund_id_unique UNIQUE (stripe_refund_id);


--
-- Name: role_permissions role_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_pkey PRIMARY KEY (id);


--
-- Name: rss_feeds rss_feeds_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rss_feeds
    ADD CONSTRAINT rss_feeds_pkey PRIMARY KEY (id);


--
-- Name: rss_feeds rss_feeds_url_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rss_feeds
    ADD CONSTRAINT rss_feeds_url_key UNIQUE (url);


--
-- Name: security_events security_events_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_pkey PRIMARY KEY (id);


--
-- Name: segment_members segment_members_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.segment_members
    ADD CONSTRAINT segment_members_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: shipping_providers shipping_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.shipping_providers
    ADD CONSTRAINT shipping_providers_pkey PRIMARY KEY (id);


--
-- Name: shipping_rates shipping_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.shipping_rates
    ADD CONSTRAINT shipping_rates_pkey PRIMARY KEY (id);


--
-- Name: social_media_connections social_media_connections_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.social_media_connections
    ADD CONSTRAINT social_media_connections_pkey PRIMARY KEY (id);


--
-- Name: ssl_certificates ssl_certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ssl_certificates
    ADD CONSTRAINT ssl_certificates_pkey PRIMARY KEY (id);


--
-- Name: sso_configurations sso_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sso_configurations
    ADD CONSTRAINT sso_configurations_pkey PRIMARY KEY (id);


--
-- Name: staging_environments staging_environments_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.staging_environments
    ADD CONSTRAINT staging_environments_pkey PRIMARY KEY (id);


--
-- Name: staging_environments staging_environments_url_key; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.staging_environments
    ADD CONSTRAINT staging_environments_url_key UNIQUE (url);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_stripe_subscription_id_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_stripe_subscription_id_unique UNIQUE (stripe_subscription_id);


--
-- Name: tax_rules tax_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tax_rules
    ADD CONSTRAINT tax_rules_pkey PRIMARY KEY (id);


--
-- Name: two_factor_attempts two_factor_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.two_factor_attempts
    ADD CONSTRAINT two_factor_attempts_pkey PRIMARY KEY (id);


--
-- Name: user_content_roles user_content_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_content_roles
    ADD CONSTRAINT user_content_roles_pkey PRIMARY KEY (id);


--
-- Name: user_permissions user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_unique UNIQUE (username);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: webhook_integrations webhook_integrations_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.webhook_integrations
    ADD CONSTRAINT webhook_integrations_pkey PRIMARY KEY (id);


--
-- Name: webhook_retries webhook_retries_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.webhook_retries
    ADD CONSTRAINT webhook_retries_pkey PRIMARY KEY (id);


--
-- Name: website_templates website_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.website_templates
    ADD CONSTRAINT website_templates_pkey PRIMARY KEY (id);


--
-- Name: website_versions website_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.website_versions
    ADD CONSTRAINT website_versions_pkey PRIMARY KEY (id);


--
-- Name: websites websites_domain_unique; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.websites
    ADD CONSTRAINT websites_domain_unique UNIQUE (domain);


--
-- Name: websites websites_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.websites
    ADD CONSTRAINT websites_pkey PRIMARY KEY (id);


--
-- Name: workflow_executions workflow_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.workflow_executions
    ADD CONSTRAINT workflow_executions_pkey PRIMARY KEY (id);


--
-- Name: account_lockouts_locked_until_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX account_lockouts_locked_until_idx ON public.account_lockouts USING btree (locked_until);


--
-- Name: account_lockouts_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX account_lockouts_user_id_idx ON public.account_lockouts USING btree (user_id);


--
-- Name: ai_cost_cost_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_cost_cost_idx ON public.ai_cost_tracking USING btree (estimated_cost);


--
-- Name: ai_cost_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_cost_created_at_idx ON public.ai_cost_tracking USING btree (created_at);


--
-- Name: ai_cost_feature_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_cost_feature_idx ON public.ai_cost_tracking USING btree (feature);


--
-- Name: ai_cost_provider_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_cost_provider_idx ON public.ai_cost_tracking USING btree (provider);


--
-- Name: ai_cost_user_feature_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_cost_user_feature_idx ON public.ai_cost_tracking USING btree (user_id, feature);


--
-- Name: ai_cost_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_cost_user_id_idx ON public.ai_cost_tracking USING btree (user_id);


--
-- Name: ai_failover_available_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_failover_available_idx ON public.ai_provider_failover USING btree (is_available);


--
-- Name: ai_failover_health_check_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_failover_health_check_idx ON public.ai_provider_failover USING btree (last_health_check_at);


--
-- Name: ai_failover_provider_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_failover_provider_idx ON public.ai_provider_failover USING btree (provider);


--
-- Name: ai_failover_provider_unique; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_failover_provider_unique ON public.ai_provider_failover USING btree (provider);


--
-- Name: ai_failover_state_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_failover_state_idx ON public.ai_provider_failover USING btree (state);


--
-- Name: ai_predictions_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_predictions_created_at_idx ON public.ai_predictions USING btree (created_at);


--
-- Name: ai_predictions_model_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_predictions_model_id_idx ON public.ai_predictions USING btree (model_id);


--
-- Name: ai_predictions_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_predictions_user_id_idx ON public.ai_predictions USING btree (user_id);


--
-- Name: ai_rate_limits_last_request_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_rate_limits_last_request_idx ON public.ai_rate_limits USING btree (last_request_at);


--
-- Name: ai_rate_limits_user_window_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_rate_limits_user_window_idx ON public.ai_rate_limits USING btree (user_id, window_start);


--
-- Name: ai_rate_limits_window_start_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_rate_limits_window_start_idx ON public.ai_rate_limits USING btree (window_start);


--
-- Name: ai_training_data_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_training_data_created_at_idx ON public.ai_training_data USING btree (created_at);


--
-- Name: ai_training_data_data_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_training_data_data_type_idx ON public.ai_training_data USING btree (data_type);


--
-- Name: ai_training_data_is_approved_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_training_data_is_approved_idx ON public.ai_training_data USING btree (is_approved);


--
-- Name: ai_training_data_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ai_training_data_user_id_idx ON public.ai_training_data USING btree (user_id);


--
-- Name: analytics_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX analytics_created_at_idx ON public.analytics USING btree (created_at);


--
-- Name: analytics_event_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX analytics_event_type_idx ON public.analytics USING btree (event_type);


--
-- Name: analytics_resource_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX analytics_resource_type_idx ON public.analytics USING btree (resource_type);


--
-- Name: analytics_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX analytics_user_id_idx ON public.analytics USING btree (user_id);


--
-- Name: api_keys_expires_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX api_keys_expires_at_idx ON public.api_keys USING btree (expires_at);


--
-- Name: api_keys_key_hash_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX api_keys_key_hash_idx ON public.api_keys USING btree (key_hash);


--
-- Name: api_keys_key_prefix_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX api_keys_key_prefix_idx ON public.api_keys USING btree (key_prefix);


--
-- Name: api_keys_user_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX api_keys_user_active_idx ON public.api_keys USING btree (user_id, revoked_at);


--
-- Name: api_keys_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX api_keys_user_id_idx ON public.api_keys USING btree (user_id);


--
-- Name: audit_logs_action_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX audit_logs_action_idx ON public.audit_logs USING btree (action);


--
-- Name: audit_logs_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX audit_logs_created_at_idx ON public.audit_logs USING btree (created_at);


--
-- Name: audit_logs_resource_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX audit_logs_resource_id_idx ON public.audit_logs USING btree (resource_id);


--
-- Name: audit_logs_resource_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX audit_logs_resource_idx ON public.audit_logs USING btree (resource);


--
-- Name: audit_logs_user_action_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX audit_logs_user_action_idx ON public.audit_logs USING btree (user_id, action);


--
-- Name: audit_logs_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX audit_logs_user_id_idx ON public.audit_logs USING btree (user_id);


--
-- Name: automation_workflows_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX automation_workflows_status_idx ON public.automation_workflows USING btree (status);


--
-- Name: automation_workflows_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX automation_workflows_user_id_idx ON public.automation_workflows USING btree (user_id);


--
-- Name: backup_jobs_completed_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX backup_jobs_completed_at_idx ON public.backup_jobs USING btree (completed_at);


--
-- Name: backup_jobs_expires_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX backup_jobs_expires_at_idx ON public.backup_jobs USING btree (expires_at);


--
-- Name: backup_jobs_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX backup_jobs_status_idx ON public.backup_jobs USING btree (status);


--
-- Name: backup_jobs_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX backup_jobs_type_idx ON public.backup_jobs USING btree (type);


--
-- Name: builder_state_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX builder_state_user_id_idx ON public.builder_state USING btree (user_id);


--
-- Name: builder_state_website_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX builder_state_website_id_idx ON public.builder_state USING btree (website_id);


--
-- Name: builder_state_website_user_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX builder_state_website_user_idx ON public.builder_state USING btree (website_id, user_id);


--
-- Name: campaigns_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX campaigns_created_at_idx ON public.campaigns USING btree (created_at);


--
-- Name: campaigns_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX campaigns_status_idx ON public.campaigns USING btree (status);


--
-- Name: campaigns_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX campaigns_type_idx ON public.campaigns USING btree (type);


--
-- Name: campaigns_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX campaigns_user_id_idx ON public.campaigns USING btree (user_id);


--
-- Name: campaigns_user_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX campaigns_user_status_idx ON public.campaigns USING btree (user_id, status);


--
-- Name: channel_integrations_channel_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX channel_integrations_channel_idx ON public.channel_integrations USING btree (channel);


--
-- Name: channel_integrations_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX channel_integrations_is_active_idx ON public.channel_integrations USING btree (is_active);


--
-- Name: channel_integrations_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX channel_integrations_user_id_idx ON public.channel_integrations USING btree (user_id);


--
-- Name: chat_messages_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX chat_messages_created_at_idx ON public.chat_messages USING btree (created_at);


--
-- Name: chat_messages_reply_to_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX chat_messages_reply_to_id_idx ON public.chat_messages USING btree (reply_to_id);


--
-- Name: chat_messages_room_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX chat_messages_room_id_idx ON public.chat_messages USING btree (room_id);


--
-- Name: chat_messages_sender_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX chat_messages_sender_id_idx ON public.chat_messages USING btree (sender_id);


--
-- Name: chat_room_members_room_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX chat_room_members_room_id_idx ON public.chat_room_members USING btree (room_id);


--
-- Name: chat_room_members_room_user_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX chat_room_members_room_user_idx ON public.chat_room_members USING btree (room_id, user_id);


--
-- Name: chat_room_members_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX chat_room_members_user_id_idx ON public.chat_room_members USING btree (user_id);


--
-- Name: chat_rooms_community_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX chat_rooms_community_id_idx ON public.chat_rooms USING btree (community_id);


--
-- Name: chat_rooms_created_by_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX chat_rooms_created_by_idx ON public.chat_rooms USING btree (created_by);


--
-- Name: chat_rooms_last_message_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX chat_rooms_last_message_at_idx ON public.chat_rooms USING btree (last_message_at);


--
-- Name: chat_rooms_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX chat_rooms_type_idx ON public.chat_rooms USING btree (type);


--
-- Name: comments_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX comments_created_at_idx ON public.comments USING btree (created_at);


--
-- Name: comments_parent_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX comments_parent_id_idx ON public.comments USING btree (parent_id);


--
-- Name: comments_post_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX comments_post_id_idx ON public.comments USING btree (post_id);


--
-- Name: comments_post_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX comments_post_status_idx ON public.comments USING btree (post_id, status);


--
-- Name: comments_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX comments_status_idx ON public.comments USING btree (status);


--
-- Name: comments_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX comments_user_id_idx ON public.comments USING btree (user_id);


--
-- Name: communities_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX communities_created_at_idx ON public.communities USING btree (created_at);


--
-- Name: communities_is_private_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX communities_is_private_idx ON public.communities USING btree (is_private);


--
-- Name: communities_owner_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX communities_owner_id_idx ON public.communities USING btree (owner_id);


--
-- Name: communities_slug_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX communities_slug_idx ON public.communities USING btree (slug);


--
-- Name: community_members_community_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX community_members_community_id_idx ON public.community_members USING btree (community_id);


--
-- Name: community_members_community_user_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX community_members_community_user_idx ON public.community_members USING btree (community_id, user_id);


--
-- Name: community_members_role_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX community_members_role_idx ON public.community_members USING btree (role);


--
-- Name: community_members_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX community_members_user_id_idx ON public.community_members USING btree (user_id);


--
-- Name: compliance_reports_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX compliance_reports_created_at_idx ON public.compliance_reports USING btree (created_at);


--
-- Name: compliance_reports_report_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX compliance_reports_report_type_idx ON public.compliance_reports USING btree (report_type);


--
-- Name: compliance_reports_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX compliance_reports_status_idx ON public.compliance_reports USING btree (status);


--
-- Name: compliance_reports_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX compliance_reports_user_id_idx ON public.compliance_reports USING btree (user_id);


--
-- Name: content_moderation_content_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX content_moderation_content_id_idx ON public.content_moderation USING btree (content_id);


--
-- Name: content_moderation_content_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX content_moderation_content_type_idx ON public.content_moderation USING btree (content_type);


--
-- Name: content_moderation_moderator_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX content_moderation_moderator_id_idx ON public.content_moderation USING btree (moderator_id);


--
-- Name: content_moderation_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX content_moderation_status_idx ON public.content_moderation USING btree (status);


--
-- Name: content_roles_name_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX content_roles_name_idx ON public.content_roles USING btree (name);


--
-- Name: content_schedule_post_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX content_schedule_post_id_idx ON public.content_schedule USING btree (post_id);


--
-- Name: content_schedule_scheduled_for_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX content_schedule_scheduled_for_idx ON public.content_schedule USING btree (scheduled_for);


--
-- Name: content_schedule_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX content_schedule_status_idx ON public.content_schedule USING btree (status);


--
-- Name: content_schedule_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX content_schedule_user_id_idx ON public.content_schedule USING btree (user_id);


--
-- Name: coupons_code_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX coupons_code_idx ON public.coupons USING btree (code);


--
-- Name: coupons_expires_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX coupons_expires_at_idx ON public.coupons USING btree (expires_at);


--
-- Name: coupons_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX coupons_is_active_idx ON public.coupons USING btree (is_active);


--
-- Name: coupons_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX coupons_user_id_idx ON public.coupons USING btree (user_id);


--
-- Name: crm_contacts_assigned_to_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX crm_contacts_assigned_to_idx ON public.crm_contacts USING btree (assigned_to);


--
-- Name: crm_contacts_email_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX crm_contacts_email_idx ON public.crm_contacts USING btree (email);


--
-- Name: crm_contacts_stage_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX crm_contacts_stage_idx ON public.crm_contacts USING btree (stage);


--
-- Name: crm_contacts_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX crm_contacts_user_id_idx ON public.crm_contacts USING btree (user_id);


--
-- Name: crm_interactions_contact_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX crm_interactions_contact_id_idx ON public.crm_interactions USING btree (contact_id);


--
-- Name: crm_interactions_scheduled_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX crm_interactions_scheduled_at_idx ON public.crm_interactions USING btree (scheduled_at);


--
-- Name: crm_interactions_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX crm_interactions_type_idx ON public.crm_interactions USING btree (type);


--
-- Name: crm_interactions_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX crm_interactions_user_id_idx ON public.crm_interactions USING btree (user_id);


--
-- Name: developer_payouts_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX developer_payouts_created_at_idx ON public.developer_payouts USING btree (created_at);


--
-- Name: developer_payouts_developer_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX developer_payouts_developer_id_idx ON public.developer_payouts USING btree (developer_id);


--
-- Name: developer_payouts_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX developer_payouts_status_idx ON public.developer_payouts USING btree (status);


--
-- Name: email_verification_tokens_expires_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX email_verification_tokens_expires_at_idx ON public.email_verification_tokens USING btree (expires_at);


--
-- Name: email_verification_tokens_token_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX email_verification_tokens_token_idx ON public.email_verification_tokens USING btree (token);


--
-- Name: email_verification_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX email_verification_tokens_user_id_idx ON public.email_verification_tokens USING btree (user_id);


--
-- Name: forum_replies_parent_reply_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX forum_replies_parent_reply_id_idx ON public.forum_replies USING btree (parent_reply_id);


--
-- Name: forum_replies_topic_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX forum_replies_topic_id_idx ON public.forum_replies USING btree (topic_id);


--
-- Name: forum_replies_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX forum_replies_user_id_idx ON public.forum_replies USING btree (user_id);


--
-- Name: forum_topics_forum_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX forum_topics_forum_id_idx ON public.forum_topics USING btree (forum_id);


--
-- Name: forum_topics_is_pinned_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX forum_topics_is_pinned_idx ON public.forum_topics USING btree (is_pinned);


--
-- Name: forum_topics_last_reply_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX forum_topics_last_reply_at_idx ON public.forum_topics USING btree (last_reply_at);


--
-- Name: forum_topics_slug_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX forum_topics_slug_idx ON public.forum_topics USING btree (slug);


--
-- Name: forum_topics_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX forum_topics_user_id_idx ON public.forum_topics USING btree (user_id);


--
-- Name: forum_votes_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX forum_votes_user_id_idx ON public.forum_votes USING btree (user_id);


--
-- Name: forum_votes_user_voteable_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX forum_votes_user_voteable_idx ON public.forum_votes USING btree (user_id, voteable_type, voteable_id);


--
-- Name: forum_votes_voteable_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX forum_votes_voteable_idx ON public.forum_votes USING btree (voteable_type, voteable_id);


--
-- Name: forums_community_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX forums_community_id_idx ON public.forums USING btree (community_id);


--
-- Name: forums_position_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX forums_position_idx ON public.forums USING btree ("position");


--
-- Name: forums_slug_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX forums_slug_idx ON public.forums USING btree (slug);


--
-- Name: gdpr_requests_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX gdpr_requests_status_idx ON public.gdpr_requests USING btree (status);


--
-- Name: gdpr_requests_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX gdpr_requests_type_idx ON public.gdpr_requests USING btree (type);


--
-- Name: gdpr_requests_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX gdpr_requests_user_id_idx ON public.gdpr_requests USING btree (user_id);


--
-- Name: gift_card_transactions_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX gift_card_transactions_created_at_idx ON public.gift_card_transactions USING btree (created_at);


--
-- Name: gift_card_transactions_gift_card_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX gift_card_transactions_gift_card_id_idx ON public.gift_card_transactions USING btree (gift_card_id);


--
-- Name: gift_card_transactions_order_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX gift_card_transactions_order_id_idx ON public.gift_card_transactions USING btree (order_id);


--
-- Name: gift_cards_code_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX gift_cards_code_idx ON public.gift_cards USING btree (code);


--
-- Name: gift_cards_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX gift_cards_is_active_idx ON public.gift_cards USING btree (is_active);


--
-- Name: gift_cards_purchased_by_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX gift_cards_purchased_by_idx ON public.gift_cards USING btree (purchased_by);


--
-- Name: gift_cards_recipient_email_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX gift_cards_recipient_email_idx ON public.gift_cards USING btree (recipient_email);


--
-- Name: helpdesk_responses_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX helpdesk_responses_created_at_idx ON public.helpdesk_responses USING btree (created_at);


--
-- Name: helpdesk_responses_ticket_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX helpdesk_responses_ticket_id_idx ON public.helpdesk_responses USING btree (ticket_id);


--
-- Name: helpdesk_responses_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX helpdesk_responses_user_id_idx ON public.helpdesk_responses USING btree (user_id);


--
-- Name: helpdesk_tickets_assigned_to_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX helpdesk_tickets_assigned_to_idx ON public.helpdesk_tickets USING btree (assigned_to);


--
-- Name: helpdesk_tickets_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX helpdesk_tickets_created_at_idx ON public.helpdesk_tickets USING btree (created_at);


--
-- Name: helpdesk_tickets_priority_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX helpdesk_tickets_priority_idx ON public.helpdesk_tickets USING btree (priority);


--
-- Name: helpdesk_tickets_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX helpdesk_tickets_status_idx ON public.helpdesk_tickets USING btree (status);


--
-- Name: helpdesk_tickets_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX helpdesk_tickets_user_id_idx ON public.helpdesk_tickets USING btree (user_id);


--
-- Name: idempotency_keys_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idempotency_keys_created_at_idx ON public.idempotency_keys USING btree (created_at);


--
-- Name: idempotency_keys_expires_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idempotency_keys_expires_at_idx ON public.idempotency_keys USING btree (expires_at);


--
-- Name: idempotency_keys_key_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idempotency_keys_key_idx ON public.idempotency_keys USING btree (key);


--
-- Name: idempotency_keys_resource_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idempotency_keys_resource_idx ON public.idempotency_keys USING btree (resource);


--
-- Name: idempotency_keys_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idempotency_keys_user_id_idx ON public.idempotency_keys USING btree (user_id);


--
-- Name: idx_community_members_community_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_community_members_community_id ON public.community_members USING btree (community_id);


--
-- Name: idx_community_members_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_community_members_user_id ON public.community_members USING btree (user_id);


--
-- Name: idx_orders_created_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_orders_created_at ON public.orders USING btree (created_at DESC);


--
-- Name: idx_orders_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_orders_status ON public.orders USING btree (status);


--
-- Name: idx_orders_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_orders_user_id ON public.orders USING btree (user_id);


--
-- Name: idx_orders_user_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_orders_user_status ON public.orders USING btree (user_id, status);


--
-- Name: idx_posts_created_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_posts_created_at ON public.posts USING btree (created_at DESC);


--
-- Name: idx_posts_status; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_posts_status ON public.posts USING btree (status);


--
-- Name: idx_posts_user_id; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_posts_user_id ON public.posts USING btree (user_id);


--
-- Name: idx_products_category; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_products_category ON public.products USING btree (category);


--
-- Name: idx_products_is_active; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_products_is_active ON public.products USING btree (is_active);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at DESC);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_users_email ON public.users USING btree (email);


--
-- Name: idx_users_username; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX idx_users_username ON public.users USING btree (username);


--
-- Name: inventory_reservations_expires_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX inventory_reservations_expires_at_idx ON public.inventory_reservations USING btree (expires_at);


--
-- Name: inventory_reservations_order_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX inventory_reservations_order_id_idx ON public.inventory_reservations USING btree (order_id);


--
-- Name: inventory_reservations_product_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX inventory_reservations_product_id_idx ON public.inventory_reservations USING btree (product_id);


--
-- Name: inventory_reservations_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX inventory_reservations_status_idx ON public.inventory_reservations USING btree (status);


--
-- Name: invoices_due_date_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX invoices_due_date_idx ON public.invoices USING btree (due_date);


--
-- Name: invoices_invoice_number_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX invoices_invoice_number_idx ON public.invoices USING btree (invoice_number);


--
-- Name: invoices_order_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX invoices_order_id_idx ON public.invoices USING btree (order_id);


--
-- Name: invoices_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX invoices_status_idx ON public.invoices USING btree (status);


--
-- Name: invoices_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX invoices_user_id_idx ON public.invoices USING btree (user_id);


--
-- Name: knowledge_base_articles_author_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX knowledge_base_articles_author_id_idx ON public.knowledge_base_articles USING btree (author_id);


--
-- Name: knowledge_base_articles_category_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX knowledge_base_articles_category_id_idx ON public.knowledge_base_articles USING btree (category_id);


--
-- Name: knowledge_base_articles_slug_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX knowledge_base_articles_slug_idx ON public.knowledge_base_articles USING btree (slug);


--
-- Name: knowledge_base_articles_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX knowledge_base_articles_status_idx ON public.knowledge_base_articles USING btree (status);


--
-- Name: knowledge_base_categories_parent_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX knowledge_base_categories_parent_id_idx ON public.knowledge_base_categories USING btree (parent_id);


--
-- Name: knowledge_base_categories_position_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX knowledge_base_categories_position_idx ON public.knowledge_base_categories USING btree ("position");


--
-- Name: knowledge_base_categories_slug_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX knowledge_base_categories_slug_idx ON public.knowledge_base_categories USING btree (slug);


--
-- Name: landing_pages_slug_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX landing_pages_slug_idx ON public.landing_pages USING btree (slug);


--
-- Name: landing_pages_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX landing_pages_status_idx ON public.landing_pages USING btree (status);


--
-- Name: landing_pages_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX landing_pages_user_id_idx ON public.landing_pages USING btree (user_id);


--
-- Name: leads_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX leads_created_at_idx ON public.leads USING btree (created_at);


--
-- Name: leads_email_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX leads_email_idx ON public.leads USING btree (email);


--
-- Name: leads_source_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX leads_source_idx ON public.leads USING btree (source);


--
-- Name: leads_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX leads_status_idx ON public.leads USING btree (status);


--
-- Name: leads_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX leads_user_id_idx ON public.leads USING btree (user_id);


--
-- Name: leads_user_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX leads_user_status_idx ON public.leads USING btree (user_id, status);


--
-- Name: login_attempts_attempted_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX login_attempts_attempted_at_idx ON public.login_attempts USING btree (attempted_at);


--
-- Name: login_attempts_identifier_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX login_attempts_identifier_idx ON public.login_attempts USING btree (identifier);


--
-- Name: login_attempts_identifier_ip_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX login_attempts_identifier_ip_idx ON public.login_attempts USING btree (identifier, ip_address);


--
-- Name: login_attempts_ip_address_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX login_attempts_ip_address_idx ON public.login_attempts USING btree (ip_address);


--
-- Name: magic_link_tokens_expires_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX magic_link_tokens_expires_at_idx ON public.magic_link_tokens USING btree (expires_at);


--
-- Name: magic_link_tokens_token_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX magic_link_tokens_token_idx ON public.magic_link_tokens USING btree (token);


--
-- Name: magic_link_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX magic_link_tokens_user_id_idx ON public.magic_link_tokens USING btree (user_id);


--
-- Name: marketing_segments_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX marketing_segments_is_active_idx ON public.marketing_segments USING btree (is_active);


--
-- Name: marketing_segments_is_dynamic_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX marketing_segments_is_dynamic_idx ON public.marketing_segments USING btree (is_dynamic);


--
-- Name: marketing_segments_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX marketing_segments_user_id_idx ON public.marketing_segments USING btree (user_id);


--
-- Name: media_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX media_created_at_idx ON public.media USING btree (created_at);


--
-- Name: media_mime_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX media_mime_type_idx ON public.media USING btree (mime_type);


--
-- Name: media_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX media_user_id_idx ON public.media USING btree (user_id);


--
-- Name: messages_community_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX messages_community_id_idx ON public.messages USING btree (community_id);


--
-- Name: messages_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX messages_created_at_idx ON public.messages USING btree (created_at);


--
-- Name: messages_is_read_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX messages_is_read_idx ON public.messages USING btree (is_read);


--
-- Name: messages_receiver_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX messages_receiver_id_idx ON public.messages USING btree (receiver_id);


--
-- Name: messages_receiver_unread_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX messages_receiver_unread_idx ON public.messages USING btree (receiver_id, is_read);


--
-- Name: messages_room_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX messages_room_id_idx ON public.messages USING btree (room_id);


--
-- Name: messages_sender_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX messages_sender_id_idx ON public.messages USING btree (sender_id);


--
-- Name: migrations_applied_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX migrations_applied_at_idx ON public.migrations USING btree (applied_at);


--
-- Name: migrations_version_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX migrations_version_idx ON public.migrations USING btree (version);


--
-- Name: moderation_actions_action_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX moderation_actions_action_idx ON public.moderation_actions USING btree (action);


--
-- Name: moderation_actions_moderator_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX moderation_actions_moderator_id_idx ON public.moderation_actions USING btree (moderator_id);


--
-- Name: moderation_actions_target_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX moderation_actions_target_id_idx ON public.moderation_actions USING btree (target_id);


--
-- Name: moderation_actions_target_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX moderation_actions_target_type_idx ON public.moderation_actions USING btree (target_type);


--
-- Name: moderation_actions_target_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX moderation_actions_target_user_id_idx ON public.moderation_actions USING btree (target_user_id);


--
-- Name: notifications_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX notifications_created_at_idx ON public.notifications USING btree (created_at);


--
-- Name: notifications_is_read_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX notifications_is_read_idx ON public.notifications USING btree (is_read);


--
-- Name: notifications_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX notifications_type_idx ON public.notifications USING btree (type);


--
-- Name: notifications_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX notifications_user_id_idx ON public.notifications USING btree (user_id);


--
-- Name: notifications_user_unread_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX notifications_user_unread_idx ON public.notifications USING btree (user_id, is_read);


--
-- Name: oauth_providers_provider_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX oauth_providers_provider_id_idx ON public.oauth_providers USING btree (provider_id);


--
-- Name: oauth_providers_provider_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX oauth_providers_provider_idx ON public.oauth_providers USING btree (provider);


--
-- Name: oauth_providers_provider_user_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX oauth_providers_provider_user_idx ON public.oauth_providers USING btree (provider, provider_id);


--
-- Name: oauth_providers_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX oauth_providers_user_id_idx ON public.oauth_providers USING btree (user_id);


--
-- Name: orders_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX orders_created_at_idx ON public.orders USING btree (created_at);


--
-- Name: orders_customer_email_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX orders_customer_email_idx ON public.orders USING btree (customer_email);


--
-- Name: orders_deleted_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX orders_deleted_at_idx ON public.orders USING btree (deleted_at);


--
-- Name: orders_fulfillment_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX orders_fulfillment_status_idx ON public.orders USING btree (fulfillment_status);


--
-- Name: orders_idempotency_key_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX orders_idempotency_key_idx ON public.orders USING btree (idempotency_key);


--
-- Name: orders_payment_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX orders_payment_status_idx ON public.orders USING btree (payment_status);


--
-- Name: orders_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX orders_status_idx ON public.orders USING btree (status);


--
-- Name: orders_stripe_payment_intent_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX orders_stripe_payment_intent_idx ON public.orders USING btree (stripe_payment_intent_id);


--
-- Name: orders_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX orders_user_id_idx ON public.orders USING btree (user_id);


--
-- Name: password_history_user_created_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX password_history_user_created_idx ON public.password_history USING btree (user_id, created_at);


--
-- Name: password_history_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX password_history_user_id_idx ON public.password_history USING btree (user_id);


--
-- Name: password_reset_tokens_expires_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX password_reset_tokens_expires_at_idx ON public.password_reset_tokens USING btree (expires_at);


--
-- Name: password_reset_tokens_token_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX password_reset_tokens_token_idx ON public.password_reset_tokens USING btree (token);


--
-- Name: password_reset_tokens_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX password_reset_tokens_user_id_idx ON public.password_reset_tokens USING btree (user_id);


--
-- Name: payment_intents_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payment_intents_created_at_idx ON public.payment_intents USING btree (created_at);


--
-- Name: payment_intents_idempotency_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payment_intents_idempotency_idx ON public.payment_intents USING btree (idempotency_key);


--
-- Name: payment_intents_order_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payment_intents_order_id_idx ON public.payment_intents USING btree (order_id);


--
-- Name: payment_intents_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payment_intents_status_idx ON public.payment_intents USING btree (status);


--
-- Name: payment_intents_stripe_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payment_intents_stripe_id_idx ON public.payment_intents USING btree (stripe_payment_intent_id);


--
-- Name: payment_intents_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX payment_intents_user_id_idx ON public.payment_intents USING btree (user_id);


--
-- Name: plugin_dependencies_depends_on_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugin_dependencies_depends_on_idx ON public.plugin_dependencies USING btree (depends_on_plugin_id);


--
-- Name: plugin_dependencies_plugin_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugin_dependencies_plugin_id_idx ON public.plugin_dependencies USING btree (plugin_id);


--
-- Name: plugin_installations_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugin_installations_is_active_idx ON public.plugin_installations USING btree (is_active);


--
-- Name: plugin_installations_plugin_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugin_installations_plugin_id_idx ON public.plugin_installations USING btree (plugin_id);


--
-- Name: plugin_installations_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugin_installations_user_id_idx ON public.plugin_installations USING btree (user_id);


--
-- Name: plugin_installations_user_plugin_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugin_installations_user_plugin_idx ON public.plugin_installations USING btree (user_id, plugin_id);


--
-- Name: plugin_licenses_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugin_licenses_is_active_idx ON public.plugin_licenses USING btree (is_active);


--
-- Name: plugin_licenses_key_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugin_licenses_key_idx ON public.plugin_licenses USING btree (key);


--
-- Name: plugin_licenses_plugin_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugin_licenses_plugin_id_idx ON public.plugin_licenses USING btree (plugin_id);


--
-- Name: plugin_licenses_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugin_licenses_user_id_idx ON public.plugin_licenses USING btree (user_id);


--
-- Name: plugin_reviews_plugin_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugin_reviews_plugin_id_idx ON public.plugin_reviews USING btree (plugin_id);


--
-- Name: plugin_reviews_rating_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugin_reviews_rating_idx ON public.plugin_reviews USING btree (rating);


--
-- Name: plugin_reviews_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugin_reviews_user_id_idx ON public.plugin_reviews USING btree (user_id);


--
-- Name: plugins_category_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugins_category_idx ON public.plugins USING btree (category);


--
-- Name: plugins_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugins_created_at_idx ON public.plugins USING btree (created_at);


--
-- Name: plugins_developer_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugins_developer_id_idx ON public.plugins USING btree (developer_id);


--
-- Name: plugins_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugins_is_active_idx ON public.plugins USING btree (is_active);


--
-- Name: plugins_rating_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX plugins_rating_idx ON public.plugins USING btree (rating);


--
-- Name: posts_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX posts_created_at_idx ON public.posts USING btree (created_at);


--
-- Name: posts_deleted_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX posts_deleted_at_idx ON public.posts USING btree (deleted_at);


--
-- Name: posts_published_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX posts_published_at_idx ON public.posts USING btree (published_at);


--
-- Name: posts_slug_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX posts_slug_idx ON public.posts USING btree (slug);


--
-- Name: posts_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX posts_status_idx ON public.posts USING btree (status);


--
-- Name: posts_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX posts_type_idx ON public.posts USING btree (type);


--
-- Name: posts_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX posts_user_id_idx ON public.posts USING btree (user_id);


--
-- Name: predictive_models_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX predictive_models_status_idx ON public.predictive_models USING btree (status);


--
-- Name: predictive_models_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX predictive_models_type_idx ON public.predictive_models USING btree (type);


--
-- Name: predictive_models_version_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX predictive_models_version_idx ON public.predictive_models USING btree (version);


--
-- Name: product_variants_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX product_variants_is_active_idx ON public.product_variants USING btree (is_active);


--
-- Name: product_variants_product_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX product_variants_product_id_idx ON public.product_variants USING btree (product_id);


--
-- Name: product_variants_sku_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX product_variants_sku_idx ON public.product_variants USING btree (sku);


--
-- Name: products_category_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX products_category_idx ON public.products USING btree (category);


--
-- Name: products_deleted_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX products_deleted_at_idx ON public.products USING btree (deleted_at);


--
-- Name: products_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX products_is_active_idx ON public.products USING btree (is_active);


--
-- Name: products_sku_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX products_sku_idx ON public.products USING btree (sku);


--
-- Name: products_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX products_user_id_idx ON public.products USING btree (user_id);


--
-- Name: refunds_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX refunds_created_at_idx ON public.refunds USING btree (created_at);


--
-- Name: refunds_order_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX refunds_order_id_idx ON public.refunds USING btree (order_id);


--
-- Name: refunds_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX refunds_status_idx ON public.refunds USING btree (status);


--
-- Name: refunds_stripe_refund_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX refunds_stripe_refund_id_idx ON public.refunds USING btree (stripe_refund_id);


--
-- Name: rss_feeds_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX rss_feeds_is_active_idx ON public.rss_feeds USING btree (is_active);


--
-- Name: rss_feeds_url_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX rss_feeds_url_idx ON public.rss_feeds USING btree (url);


--
-- Name: rss_feeds_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX rss_feeds_user_id_idx ON public.rss_feeds USING btree (user_id);


--
-- Name: security_events_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX security_events_created_at_idx ON public.security_events USING btree (created_at);


--
-- Name: security_events_event_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX security_events_event_type_idx ON public.security_events USING btree (event_type);


--
-- Name: security_events_severity_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX security_events_severity_idx ON public.security_events USING btree (severity);


--
-- Name: security_events_user_event_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX security_events_user_event_idx ON public.security_events USING btree (user_id, event_type);


--
-- Name: security_events_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX security_events_user_id_idx ON public.security_events USING btree (user_id);


--
-- Name: segment_members_contact_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX segment_members_contact_id_idx ON public.segment_members USING btree (contact_id);


--
-- Name: segment_members_lead_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX segment_members_lead_id_idx ON public.segment_members USING btree (lead_id);


--
-- Name: segment_members_segment_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX segment_members_segment_id_idx ON public.segment_members USING btree (segment_id);


--
-- Name: sessions_expires_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX sessions_expires_at_idx ON public.sessions USING btree (expires_at);


--
-- Name: sessions_ip_address_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX sessions_ip_address_idx ON public.sessions USING btree (ip_address);


--
-- Name: sessions_last_activity_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX sessions_last_activity_idx ON public.sessions USING btree (last_activity_at);


--
-- Name: sessions_user_device_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX sessions_user_device_idx ON public.sessions USING btree (user_id, device_fingerprint) WHERE (device_fingerprint IS NOT NULL);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX sessions_user_id_idx ON public.sessions USING btree (user_id);


--
-- Name: shipping_providers_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX shipping_providers_is_active_idx ON public.shipping_providers USING btree (is_active);


--
-- Name: shipping_providers_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX shipping_providers_user_id_idx ON public.shipping_providers USING btree (user_id);


--
-- Name: shipping_rates_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX shipping_rates_is_active_idx ON public.shipping_rates USING btree (is_active);


--
-- Name: shipping_rates_provider_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX shipping_rates_provider_id_idx ON public.shipping_rates USING btree (provider_id);


--
-- Name: social_media_connections_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX social_media_connections_is_active_idx ON public.social_media_connections USING btree (is_active);


--
-- Name: social_media_connections_platform_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX social_media_connections_platform_idx ON public.social_media_connections USING btree (platform);


--
-- Name: social_media_connections_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX social_media_connections_user_id_idx ON public.social_media_connections USING btree (user_id);


--
-- Name: ssl_certificates_domain_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ssl_certificates_domain_idx ON public.ssl_certificates USING btree (domain);


--
-- Name: ssl_certificates_expires_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ssl_certificates_expires_at_idx ON public.ssl_certificates USING btree (expires_at);


--
-- Name: ssl_certificates_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ssl_certificates_status_idx ON public.ssl_certificates USING btree (status);


--
-- Name: ssl_certificates_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX ssl_certificates_user_id_idx ON public.ssl_certificates USING btree (user_id);


--
-- Name: sso_configurations_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX sso_configurations_is_active_idx ON public.sso_configurations USING btree (is_active);


--
-- Name: sso_configurations_provider_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX sso_configurations_provider_idx ON public.sso_configurations USING btree (provider);


--
-- Name: sso_configurations_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX sso_configurations_user_id_idx ON public.sso_configurations USING btree (user_id);


--
-- Name: staging_environments_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX staging_environments_status_idx ON public.staging_environments USING btree (status);


--
-- Name: staging_environments_website_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX staging_environments_website_id_idx ON public.staging_environments USING btree (website_id);


--
-- Name: subscription_plans_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX subscription_plans_is_active_idx ON public.subscription_plans USING btree (is_active);


--
-- Name: subscriptions_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX subscriptions_status_idx ON public.subscriptions USING btree (status);


--
-- Name: subscriptions_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX subscriptions_user_id_idx ON public.subscriptions USING btree (user_id);


--
-- Name: tax_rules_country_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX tax_rules_country_idx ON public.tax_rules USING btree (country);


--
-- Name: tax_rules_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX tax_rules_is_active_idx ON public.tax_rules USING btree (is_active);


--
-- Name: tax_rules_state_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX tax_rules_state_idx ON public.tax_rules USING btree (state);


--
-- Name: tax_rules_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX tax_rules_user_id_idx ON public.tax_rules USING btree (user_id);


--
-- Name: two_factor_attempts_attempted_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX two_factor_attempts_attempted_at_idx ON public.two_factor_attempts USING btree (attempted_at);


--
-- Name: two_factor_attempts_ip_address_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX two_factor_attempts_ip_address_idx ON public.two_factor_attempts USING btree (ip_address);


--
-- Name: two_factor_attempts_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX two_factor_attempts_user_id_idx ON public.two_factor_attempts USING btree (user_id);


--
-- Name: two_factor_attempts_user_ip_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX two_factor_attempts_user_ip_idx ON public.two_factor_attempts USING btree (user_id, ip_address);


--
-- Name: user_content_roles_role_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX user_content_roles_role_id_idx ON public.user_content_roles USING btree (role_id);


--
-- Name: user_content_roles_scope_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX user_content_roles_scope_idx ON public.user_content_roles USING btree (scope, scope_id);


--
-- Name: user_content_roles_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX user_content_roles_user_id_idx ON public.user_content_roles USING btree (user_id);


--
-- Name: users_deleted_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX users_deleted_at_idx ON public.users USING btree (deleted_at);


--
-- Name: users_email_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX users_email_idx ON public.users USING btree (email);


--
-- Name: users_role_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX users_role_idx ON public.users USING btree (role);


--
-- Name: users_stripe_customer_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX users_stripe_customer_idx ON public.users USING btree (stripe_customer_id);


--
-- Name: users_subscription_tier_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX users_subscription_tier_idx ON public.users USING btree (subscription_tier);


--
-- Name: webhook_events_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX webhook_events_created_at_idx ON public.webhook_events USING btree (created_at);


--
-- Name: webhook_events_processed_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX webhook_events_processed_idx ON public.webhook_events USING btree (processed);


--
-- Name: webhook_events_type_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX webhook_events_type_idx ON public.webhook_events USING btree (type);


--
-- Name: webhook_integrations_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX webhook_integrations_is_active_idx ON public.webhook_integrations USING btree (is_active);


--
-- Name: webhook_integrations_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX webhook_integrations_user_id_idx ON public.webhook_integrations USING btree (user_id);


--
-- Name: webhook_integrations_website_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX webhook_integrations_website_id_idx ON public.webhook_integrations USING btree (website_id);


--
-- Name: webhook_retries_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX webhook_retries_created_at_idx ON public.webhook_retries USING btree (created_at);


--
-- Name: webhook_retries_event_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX webhook_retries_event_id_idx ON public.webhook_retries USING btree (webhook_event_id);


--
-- Name: webhook_retries_next_retry_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX webhook_retries_next_retry_idx ON public.webhook_retries USING btree (next_retry_at);


--
-- Name: webhook_retries_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX webhook_retries_status_idx ON public.webhook_retries USING btree (status);


--
-- Name: website_templates_category_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX website_templates_category_idx ON public.website_templates USING btree (category);


--
-- Name: website_templates_creator_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX website_templates_creator_id_idx ON public.website_templates USING btree (creator_id);


--
-- Name: website_templates_featured_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX website_templates_featured_idx ON public.website_templates USING btree (is_featured);


--
-- Name: website_templates_industry_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX website_templates_industry_idx ON public.website_templates USING btree (industry);


--
-- Name: website_templates_is_active_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX website_templates_is_active_idx ON public.website_templates USING btree (is_active);


--
-- Name: website_templates_rating_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX website_templates_rating_idx ON public.website_templates USING btree (rating);


--
-- Name: website_versions_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX website_versions_created_at_idx ON public.website_versions USING btree (created_at);


--
-- Name: website_versions_website_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX website_versions_website_id_idx ON public.website_versions USING btree (website_id);


--
-- Name: website_versions_website_version_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX website_versions_website_version_idx ON public.website_versions USING btree (website_id, version);


--
-- Name: websites_deleted_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX websites_deleted_at_idx ON public.websites USING btree (deleted_at);


--
-- Name: websites_domain_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX websites_domain_idx ON public.websites USING btree (domain);


--
-- Name: websites_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX websites_status_idx ON public.websites USING btree (status);


--
-- Name: websites_user_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX websites_user_id_idx ON public.websites USING btree (user_id);


--
-- Name: workflow_executions_created_at_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX workflow_executions_created_at_idx ON public.workflow_executions USING btree (created_at);


--
-- Name: workflow_executions_status_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX workflow_executions_status_idx ON public.workflow_executions USING btree (status);


--
-- Name: workflow_executions_workflow_id_idx; Type: INDEX; Schema: public; Owner: neondb_owner
--

CREATE INDEX workflow_executions_workflow_id_idx ON public.workflow_executions USING btree (workflow_id);


--
-- Name: ab_test_participants ab_test_participants_test_id_ab_tests_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ab_test_participants
    ADD CONSTRAINT ab_test_participants_test_id_ab_tests_id_fk FOREIGN KEY (test_id) REFERENCES public.ab_tests(id) ON DELETE CASCADE;


--
-- Name: ab_tests ab_tests_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ab_tests
    ADD CONSTRAINT ab_tests_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: account_lockouts account_lockouts_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.account_lockouts
    ADD CONSTRAINT account_lockouts_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: affiliates affiliates_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.affiliates
    ADD CONSTRAINT affiliates_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_cost_tracking ai_cost_tracking_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ai_cost_tracking
    ADD CONSTRAINT ai_cost_tracking_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ai_predictions ai_predictions_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ai_predictions
    ADD CONSTRAINT ai_predictions_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.predictive_models(id) ON DELETE CASCADE;


--
-- Name: ai_predictions ai_predictions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ai_predictions
    ADD CONSTRAINT ai_predictions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ai_rate_limits ai_rate_limits_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ai_rate_limits
    ADD CONSTRAINT ai_rate_limits_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ai_training_data ai_training_data_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ai_training_data
    ADD CONSTRAINT ai_training_data_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: analytics analytics_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.analytics
    ADD CONSTRAINT analytics_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: api_keys api_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: automation_workflows automation_workflows_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.automation_workflows
    ADD CONSTRAINT automation_workflows_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: builder_state builder_state_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.builder_state
    ADD CONSTRAINT builder_state_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: builder_state builder_state_website_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.builder_state
    ADD CONSTRAINT builder_state_website_id_fkey FOREIGN KEY (website_id) REFERENCES public.websites(id) ON DELETE CASCADE;


--
-- Name: campaigns campaigns_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.campaigns
    ADD CONSTRAINT campaigns_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: channel_integrations channel_integrations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.channel_integrations
    ADD CONSTRAINT channel_integrations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.chat_rooms(id) ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_room_members chat_room_members_room_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_room_members
    ADD CONSTRAINT chat_room_members_room_id_fkey FOREIGN KEY (room_id) REFERENCES public.chat_rooms(id) ON DELETE CASCADE;


--
-- Name: chat_room_members chat_room_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_room_members
    ADD CONSTRAINT chat_room_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: chat_rooms chat_rooms_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_rooms
    ADD CONSTRAINT chat_rooms_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: chat_rooms chat_rooms_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.chat_rooms
    ADD CONSTRAINT chat_rooms_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: comments comments_post_id_posts_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_post_id_posts_id_fk FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: comments comments_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.comments
    ADD CONSTRAINT comments_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: communities communities_owner_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.communities
    ADD CONSTRAINT communities_owner_id_users_id_fk FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: community_members community_members_community_id_communities_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.community_members
    ADD CONSTRAINT community_members_community_id_communities_id_fk FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: community_members community_members_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.community_members
    ADD CONSTRAINT community_members_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: compliance_reports compliance_reports_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.compliance_reports
    ADD CONSTRAINT compliance_reports_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: content_moderation content_moderation_moderator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.content_moderation
    ADD CONSTRAINT content_moderation_moderator_id_fkey FOREIGN KEY (moderator_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: content_schedule content_schedule_post_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.content_schedule
    ADD CONSTRAINT content_schedule_post_id_fkey FOREIGN KEY (post_id) REFERENCES public.posts(id) ON DELETE CASCADE;


--
-- Name: content_schedule content_schedule_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.content_schedule
    ADD CONSTRAINT content_schedule_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: coupons coupons_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.coupons
    ADD CONSTRAINT coupons_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: crm_contacts crm_contacts_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.crm_contacts
    ADD CONSTRAINT crm_contacts_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: crm_contacts crm_contacts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.crm_contacts
    ADD CONSTRAINT crm_contacts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: crm_interactions crm_interactions_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.crm_interactions
    ADD CONSTRAINT crm_interactions_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.crm_contacts(id) ON DELETE CASCADE;


--
-- Name: crm_interactions crm_interactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.crm_interactions
    ADD CONSTRAINT crm_interactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: developer_payouts developer_payouts_developer_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.developer_payouts
    ADD CONSTRAINT developer_payouts_developer_id_fkey FOREIGN KEY (developer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: email_verification_tokens email_verification_tokens_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_replies forum_replies_topic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.forum_replies
    ADD CONSTRAINT forum_replies_topic_id_fkey FOREIGN KEY (topic_id) REFERENCES public.forum_topics(id) ON DELETE CASCADE;


--
-- Name: forum_replies forum_replies_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.forum_replies
    ADD CONSTRAINT forum_replies_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_topics forum_topics_forum_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.forum_topics
    ADD CONSTRAINT forum_topics_forum_id_fkey FOREIGN KEY (forum_id) REFERENCES public.forums(id) ON DELETE CASCADE;


--
-- Name: forum_topics forum_topics_last_reply_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.forum_topics
    ADD CONSTRAINT forum_topics_last_reply_by_fkey FOREIGN KEY (last_reply_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: forum_topics forum_topics_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.forum_topics
    ADD CONSTRAINT forum_topics_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forum_votes forum_votes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.forum_votes
    ADD CONSTRAINT forum_votes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: forums forums_community_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.forums
    ADD CONSTRAINT forums_community_id_fkey FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: funnel_entries funnel_entries_funnel_id_funnels_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.funnel_entries
    ADD CONSTRAINT funnel_entries_funnel_id_funnels_id_fk FOREIGN KEY (funnel_id) REFERENCES public.funnels(id) ON DELETE CASCADE;


--
-- Name: funnel_entries funnel_entries_lead_id_leads_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.funnel_entries
    ADD CONSTRAINT funnel_entries_lead_id_leads_id_fk FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE SET NULL;


--
-- Name: funnels funnels_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.funnels
    ADD CONSTRAINT funnels_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: gdpr_requests gdpr_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gdpr_requests
    ADD CONSTRAINT gdpr_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: gift_card_transactions gift_card_transactions_gift_card_id_gift_cards_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gift_card_transactions
    ADD CONSTRAINT gift_card_transactions_gift_card_id_gift_cards_id_fk FOREIGN KEY (gift_card_id) REFERENCES public.gift_cards(id) ON DELETE CASCADE;


--
-- Name: gift_card_transactions gift_card_transactions_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gift_card_transactions
    ADD CONSTRAINT gift_card_transactions_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: gift_cards gift_cards_purchased_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.gift_cards
    ADD CONSTRAINT gift_cards_purchased_by_users_id_fk FOREIGN KEY (purchased_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: helpdesk_responses helpdesk_responses_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.helpdesk_responses
    ADD CONSTRAINT helpdesk_responses_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.helpdesk_tickets(id) ON DELETE CASCADE;


--
-- Name: helpdesk_responses helpdesk_responses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.helpdesk_responses
    ADD CONSTRAINT helpdesk_responses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: helpdesk_tickets helpdesk_tickets_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.helpdesk_tickets
    ADD CONSTRAINT helpdesk_tickets_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: helpdesk_tickets helpdesk_tickets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.helpdesk_tickets
    ADD CONSTRAINT helpdesk_tickets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: idempotency_keys idempotency_keys_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: inventory_reservations inventory_reservations_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.inventory_reservations
    ADD CONSTRAINT inventory_reservations_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_order_id_fkey FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: knowledge_base_articles knowledge_base_articles_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.knowledge_base_articles
    ADD CONSTRAINT knowledge_base_articles_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: knowledge_base_articles knowledge_base_articles_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.knowledge_base_articles
    ADD CONSTRAINT knowledge_base_articles_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.knowledge_base_categories(id) ON DELETE SET NULL;


--
-- Name: landing_pages landing_pages_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.landing_pages
    ADD CONSTRAINT landing_pages_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: leads leads_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.leads
    ADD CONSTRAINT leads_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: magic_link_tokens magic_link_tokens_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.magic_link_tokens
    ADD CONSTRAINT magic_link_tokens_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: marketing_segments marketing_segments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.marketing_segments
    ADD CONSTRAINT marketing_segments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: media media_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.media
    ADD CONSTRAINT media_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_community_id_communities_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_community_id_communities_id_fk FOREIGN KEY (community_id) REFERENCES public.communities(id) ON DELETE CASCADE;


--
-- Name: messages messages_receiver_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_receiver_id_users_id_fk FOREIGN KEY (receiver_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: messages messages_sender_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_sender_id_users_id_fk FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: moderation_actions moderation_actions_moderator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.moderation_actions
    ADD CONSTRAINT moderation_actions_moderator_id_fkey FOREIGN KEY (moderator_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: moderation_actions moderation_actions_target_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.moderation_actions
    ADD CONSTRAINT moderation_actions_target_user_id_fkey FOREIGN KEY (target_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: notifications notifications_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: oauth_providers oauth_providers_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.oauth_providers
    ADD CONSTRAINT oauth_providers_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: orders orders_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: orders orders_website_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.orders
    ADD CONSTRAINT orders_website_id_fkey FOREIGN KEY (website_id) REFERENCES public.websites(id) ON DELETE SET NULL;


--
-- Name: password_history password_history_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_history
    ADD CONSTRAINT password_history_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: password_reset_tokens password_reset_tokens_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: payment_intents payment_intents_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payment_intents
    ADD CONSTRAINT payment_intents_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE SET NULL;


--
-- Name: payment_intents payment_intents_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.payment_intents
    ADD CONSTRAINT payment_intents_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: plugin_dependencies plugin_dependencies_depends_on_plugin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugin_dependencies
    ADD CONSTRAINT plugin_dependencies_depends_on_plugin_id_fkey FOREIGN KEY (depends_on_plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_dependencies plugin_dependencies_plugin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugin_dependencies
    ADD CONSTRAINT plugin_dependencies_plugin_id_fkey FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_installations plugin_installations_plugin_id_plugins_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugin_installations
    ADD CONSTRAINT plugin_installations_plugin_id_plugins_id_fk FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_installations plugin_installations_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugin_installations
    ADD CONSTRAINT plugin_installations_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: plugin_licenses plugin_licenses_plugin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugin_licenses
    ADD CONSTRAINT plugin_licenses_plugin_id_fkey FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_licenses plugin_licenses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugin_licenses
    ADD CONSTRAINT plugin_licenses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: plugin_reviews plugin_reviews_plugin_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugin_reviews
    ADD CONSTRAINT plugin_reviews_plugin_id_fkey FOREIGN KEY (plugin_id) REFERENCES public.plugins(id) ON DELETE CASCADE;


--
-- Name: plugin_reviews plugin_reviews_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugin_reviews
    ADD CONSTRAINT plugin_reviews_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: plugins plugins_developer_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.plugins
    ADD CONSTRAINT plugins_developer_id_users_id_fk FOREIGN KEY (developer_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: posts posts_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: product_variants product_variants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id) ON DELETE CASCADE;


--
-- Name: products products_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: referrals referrals_affiliate_id_affiliates_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_affiliate_id_affiliates_id_fk FOREIGN KEY (affiliate_id) REFERENCES public.affiliates(id) ON DELETE CASCADE;


--
-- Name: referrals referrals_referred_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.referrals
    ADD CONSTRAINT referrals_referred_user_id_users_id_fk FOREIGN KEY (referred_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: refunds refunds_initiated_by_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_initiated_by_users_id_fk FOREIGN KEY (initiated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: refunds refunds_order_id_orders_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.refunds
    ADD CONSTRAINT refunds_order_id_orders_id_fk FOREIGN KEY (order_id) REFERENCES public.orders(id) ON DELETE CASCADE;


--
-- Name: role_permissions role_permissions_permission_id_permissions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.role_permissions
    ADD CONSTRAINT role_permissions_permission_id_permissions_id_fk FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: rss_feeds rss_feeds_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.rss_feeds
    ADD CONSTRAINT rss_feeds_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: security_events security_events_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.sessions(id) ON DELETE CASCADE;


--
-- Name: security_events security_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.security_events
    ADD CONSTRAINT security_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: segment_members segment_members_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.segment_members
    ADD CONSTRAINT segment_members_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.crm_contacts(id) ON DELETE CASCADE;


--
-- Name: segment_members segment_members_lead_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.segment_members
    ADD CONSTRAINT segment_members_lead_id_fkey FOREIGN KEY (lead_id) REFERENCES public.leads(id) ON DELETE CASCADE;


--
-- Name: segment_members segment_members_segment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.segment_members
    ADD CONSTRAINT segment_members_segment_id_fkey FOREIGN KEY (segment_id) REFERENCES public.marketing_segments(id) ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: shipping_providers shipping_providers_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.shipping_providers
    ADD CONSTRAINT shipping_providers_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: shipping_rates shipping_rates_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.shipping_rates
    ADD CONSTRAINT shipping_rates_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.shipping_providers(id) ON DELETE CASCADE;


--
-- Name: social_media_connections social_media_connections_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.social_media_connections
    ADD CONSTRAINT social_media_connections_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: ssl_certificates ssl_certificates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.ssl_certificates
    ADD CONSTRAINT ssl_certificates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: sso_configurations sso_configurations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.sso_configurations
    ADD CONSTRAINT sso_configurations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: staging_environments staging_environments_deployed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.staging_environments
    ADD CONSTRAINT staging_environments_deployed_by_fkey FOREIGN KEY (deployed_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: staging_environments staging_environments_website_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.staging_environments
    ADD CONSTRAINT staging_environments_website_id_fkey FOREIGN KEY (website_id) REFERENCES public.websites(id) ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: tax_rules tax_rules_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.tax_rules
    ADD CONSTRAINT tax_rules_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: two_factor_attempts two_factor_attempts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.two_factor_attempts
    ADD CONSTRAINT two_factor_attempts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_content_roles user_content_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_content_roles
    ADD CONSTRAINT user_content_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.content_roles(id) ON DELETE CASCADE;


--
-- Name: user_content_roles user_content_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_content_roles
    ADD CONSTRAINT user_content_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_permissions user_permissions_permission_id_permissions_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_permission_id_permissions_id_fk FOREIGN KEY (permission_id) REFERENCES public.permissions(id) ON DELETE CASCADE;


--
-- Name: user_permissions user_permissions_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.user_permissions
    ADD CONSTRAINT user_permissions_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: webhook_integrations webhook_integrations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.webhook_integrations
    ADD CONSTRAINT webhook_integrations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: webhook_integrations webhook_integrations_website_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.webhook_integrations
    ADD CONSTRAINT webhook_integrations_website_id_fkey FOREIGN KEY (website_id) REFERENCES public.websites(id) ON DELETE CASCADE;


--
-- Name: webhook_retries webhook_retries_webhook_event_id_webhook_events_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.webhook_retries
    ADD CONSTRAINT webhook_retries_webhook_event_id_webhook_events_id_fk FOREIGN KEY (webhook_event_id) REFERENCES public.webhook_events(id) ON DELETE CASCADE;


--
-- Name: website_templates website_templates_creator_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.website_templates
    ADD CONSTRAINT website_templates_creator_id_fkey FOREIGN KEY (creator_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: website_versions website_versions_website_id_websites_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.website_versions
    ADD CONSTRAINT website_versions_website_id_websites_id_fk FOREIGN KEY (website_id) REFERENCES public.websites(id) ON DELETE CASCADE;


--
-- Name: websites websites_user_id_users_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.websites
    ADD CONSTRAINT websites_user_id_users_id_fk FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workflow_executions workflow_executions_workflow_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: neondb_owner
--

ALTER TABLE ONLY public.workflow_executions
    ADD CONSTRAINT workflow_executions_workflow_id_fkey FOREIGN KEY (workflow_id) REFERENCES public.automation_workflows(id) ON DELETE CASCADE;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON SEQUENCES TO neon_superuser WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: cloud_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE cloud_admin IN SCHEMA public GRANT ALL ON TABLES TO neon_superuser WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

